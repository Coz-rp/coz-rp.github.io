<codex>
When soul play meets bodies taken by someone else:
- Only a body whose soul was actually taken shows something missing. A possessed, worn, absorbed or swapped body keeps its soul and shows nothing off, and running several bodies doesn't split anyone's soul.
</codex>
