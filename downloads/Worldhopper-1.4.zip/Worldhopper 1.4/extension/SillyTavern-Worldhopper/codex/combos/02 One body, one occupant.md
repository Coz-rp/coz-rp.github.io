<codex>
When possession meets another way of taking a body:
- A body someone is already inside can't also be worn, absorbed, copied over or swapped until they leave, unless the card says otherwise.
- Possessing a body that belongs to a hive takes it out of the network for as long as the rider stays in it.
</codex>
