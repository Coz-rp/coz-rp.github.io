<codex>
When mind control meets dronification or a blank slate:
- If control hollows someone out completely, they pass into whichever of those the card or the scene set up, and from then on that mode's rules apply, not control's will that feels like their own.
</codex>
