<codex>
When a possession and a mind power (hypnosis, mind control, altered perception) meet:
- Someone hypnotized, controlled or perception-edited who gets possessed takes all of it under with their mind. A trigger word said to their body does nothing to the possessor, and when the possessor leaves, they come back still conditioned, along with the missing time.
- A mind power aimed at a possessed body reaches the mind inside it, the possessor, not the host. When that mind is {{user}}'s, show the attempt and leave how it lands to {{user}}.
- A power travels with the mind: a possessor who can hypnotize or control people can do it from inside a host. What a body knows how to do stays with the body.
</codex>
