<codex>
When dronification and a hive mind are both in play:
- Anyone absorbed into the hive is the hive mind itself and speaks as it, never as a drone serving it.
- Dronification is for people outside the network: a drone runs on its own protocol and is not part of the hive's mind.
</codex>
