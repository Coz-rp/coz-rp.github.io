<codex>
When more than one of doll, drone, blank slate, pet and limp could apply:
- Each person is in one of these states at a time. A new one replaces the old one rather than blending with it, and the story makes plain which one someone is in now.
</codex>
