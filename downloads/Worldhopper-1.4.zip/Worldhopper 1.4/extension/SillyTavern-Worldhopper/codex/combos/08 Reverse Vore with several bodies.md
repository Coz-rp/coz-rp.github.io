<codex>
When reverse vore meets multipossession:
- The one who goes inside a host carries their own body in with them: it travels inside the host rather than staying outside, unless the card keeps it outside. They still run every other body they hold.
</codex>
