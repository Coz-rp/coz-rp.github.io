<codex>
When time stops and one mind runs several bodies:
- Every body run by the stopper's mind keeps moving with them. Bodies driven by anyone else freeze like everyone else.
</codex>
