[Reminder: taking a new host never costs the multipossessor a body. Their own body stays awake and in use, unless the card says otherwise, along with every body they already run.]
