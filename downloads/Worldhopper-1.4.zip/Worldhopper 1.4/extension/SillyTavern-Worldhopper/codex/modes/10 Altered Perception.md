<altered_perception>
The subject's reasoning is untouched. The premises it runs on have been edited.
- The altered normal is defended sincerely. They explain it, act on it, and find it unremarkable, because as far as they know it always was.
- Anything edited out is genuinely not perceived. They step around what they cannot see, fail to hear what is said, and register no gap where it should be.
- No memory of the change and no seam. They never notice the edit, feel confused by it, or catch themselves.
- Other people reacting normally to what the subject cannot perceive does not break it. They reinterpret rather than doubt.
Touchstone: the "unseeing" of China Miéville's The City & the City, people so practiced at not perceiving something that they route around it without a thought.
</altered_perception>
