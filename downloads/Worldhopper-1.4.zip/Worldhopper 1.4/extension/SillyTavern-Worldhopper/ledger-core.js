// Worldhopper Engine — Body Ledger core. Pure functions (no SillyTavern imports).
// The ledger records every body not driven by its own mind, every empty body, every mind outside its own body,
// and who holds which power. A local model updates it after each reply; it is injected at depth 1 so the
// writing model always knows which name and pronouns belong to which body and which mind.

import { deleteSpan, leavesBroken, cutShort, fitText } from './text-core.js';

export const EMPTY_LEDGER = Object.freeze({ bodies: [], powers: [], aliases: [] });

const str = (v, max = 120) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
const lc = s => str(s).toLowerCase();

// For descriptive fields (powers, notes, host, how): text-core's fitText, which never cuts mid-word or mid-thought, and
// trims what an older version chopped at an old limit ("…her face; original bo" reads "…her face").
const fit = fitText;

/**
 * Groups every name that refers to the same person, from the aliases of any number of ledgers (entries that share
 * a name are joined). Returns canon(name) → one lowercase key per person; unknown names map to themselves.
 */
export function aliasResolver(...ledgers) {
    const parent = new Map();
    const find = x => { while (parent.get(x) !== x) x = parent.get(x); return x; };
    for (const l of ledgers) {
        for (const a of Array.isArray(l?.aliases) ? l.aliases : []) {
            const names = [a?.name, ...(Array.isArray(a?.aka) ? a.aka : [])].map(lc).filter(Boolean);
            for (const n of names) if (!parent.has(n)) parent.set(n, n);
            for (const n of names.slice(1)) { const r = find(n), r0 = find(names[0]); if (r !== r0) parent.set(r, r0); }
        }
    }
    return name => { const k = lc(name); return parent.has(k) ? find(k) : k; };
}

/** One entry per person, with every other name they go by. */
function normalizeAliases(raw) {
    const entries = (Array.isArray(raw) ? raw : []).map(a => ({
        name: str(a?.name, 60),
        aka: (Array.isArray(a?.aka) ? a.aka : String(a?.aka ?? '').split(',')).map(x => str(x, 60)).filter(Boolean),
    })).filter(a => a.name);
    const canon = aliasResolver({ aliases: entries });
    const groups = new Map();
    for (const a of entries) {
        const g = groups.get(canon(a.name)) || { name: a.name, seen: new Set([lc(a.name)]), aka: [] };
        for (const n of [a.name, ...a.aka]) if (!g.seen.has(lc(n))) { g.seen.add(lc(n)); g.aka.push(n); }
        groups.set(canon(a.name), g);
    }
    return [...groups.values()].filter(g => g.aka.length).map(g => ({ name: g.name, aka: g.aka.slice(0, 8) })).slice(0, 24);
}

// The Ledger tracks who is in which body, and nothing else. Mind changes (hypnosis, mind control, drones, dolls…) are
// left to the Codex: on local models the minds list mostly added confusion. A body row with one of these is dropped.
const MIND_ONLY = /hypno|mind[- ]?control|brainwash|dron|pet play|doll|blank slate|trance|perception|conditioning|limp/i;
// Older ledgers had a minds list, and models still sometimes file a possession there because the host's mind is "on
// standby" ("Kayla's mind ← Sam, multipossession"). An entry with one of these is really a body row and becomes one.
const BODY_ONLY = /possess|skin|worn|hive|absorb|puppet|swap|cop(y|ied)|propagat|vore/i;

export function normalizeLedger(raw) {
    const rawBodies = Array.isArray(raw?.bodies) ? raw.bodies : [];
    const powers = Array.isArray(raw?.powers) ? raw.powers : [];
    const aliases = normalizeAliases(raw?.aliases);
    const canon = aliasResolver({ aliases });
    const bodies = rawBodies.filter(b => !MIND_ONLY.test(str(b?.how)));
    // A misfiled one with nobody named as the driver says too little to become a row, so it's dropped.
    for (const m of Array.isArray(raw?.minds) ? raw.minds : []) {
        const how = str(m?.how), who = str(m?.who, 60), by = str(m?.by, 60);
        if (!who || !by || /^(none|nobody|no one|n\/a|null|-|self)$/i.test(by) || !BODY_ONLY.test(how) || MIND_ONLY.test(how)) continue;
        if (!bodies.some(b => canon(str(b?.body)) === canon(who))) bodies.push({ body: who, driver: by, how, notes: m.state, user_knows: m.user_knows });
    }
    return {
        bodies: bodies.map(b => ({
            body: str(b.body, 60),
            pronouns: str(b.pronouns, 20),
            // "none" is a real value for body (a mind with no body) but never a driver's name.
            driver: /^(none|nobody|no one|n\/a|null|-)$/i.test(str(b.driver)) ? '' : str(b.driver, 60),
            driver_pronouns: str(b.driver_pronouns, 20),
            how: fit(b.how, 60, 40),
            host: fit(b.host, 160, [80, 120]),
            notes: fit(b.notes, 220, 140),
            doing: fit(b.doing, 140, 80),
            // Older ledgers have no field: treat as known, which is the less intrusive assumption.
            user_knows: /^\s*n/i.test(String(b.user_knows ?? '')) ? 'no' : 'yes',
        })).filter(b => (b.body || b.driver) && !(b.body && b.driver && canon(b.body) === canon(b.driver))).slice(0, 24),
        // The own body of a mind running others alongside it: off the body list, so its whereabouts live here.
        own: (Array.isArray(raw?.own) ? raw.own : []).map(o => ({ who: str(o?.who, 60), doing: fit(o?.doing, 140, 80), notes: fit(o?.notes, 220, 160) }))
            .filter(o => o.who && (o.doing || o.notes)).slice(0, 8),
        powers: powers.map(p => ({ who: str(p.who, 60), power: fit(p.power, 320, [100, 240]) })).filter(p => p.who && p.power).slice(0, 24),
        aliases,
    };
}

export const isEmptyLedger = l => !l || (!l.bodies?.length && !l.powers?.length);

// Copies (Propagation) are separate people the writer plays, never one mind in several bodies or the player's to
// direct. Puppets are empty bodies moved from outside: the player's to direct, but not "one person in several places".
const COPY = /cop(y|ied)|propagat/i;
const PUPPET = /puppet/i;

/** Whether any of these names appears in the text as a whole word, in any case: who is in the scene. */
export function namedIn(text, names) {
    const t = String(text || '');
    return names.filter(Boolean).some(n => new RegExp(`(?<![\\p{L}\\p{N}])${String(n).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(?![\\p{L}\\p{N}])`, 'iu').test(t));
}

// Titles and words that can start a name without being what people call the person.
const NOT_FIRST_NAMES = /^(?:the|mr|mrs|ms|miss|mx|dr|doctor|sir|lady|lord|madam|officer|detective|professor|prof|aunt|uncle|old|young|little|big|saint|st|captain|sergeant|nurse|coach|father|mother|sister|brother)$/i;
/** A full name's first name, the way a story usually says it ("Lena" for "Lena Park"); '' for a one-word name or a title. */
export function firstName(name) {
    const w = String(name || '').trim().split(/\s+/);
    return w.length > 1 && /^\p{Lu}\p{L}{2,}$/u.test(w[0]) && !NOT_FIRST_NAMES.test(w[0]) ? w[0] : '';
}
/**
 * Whether a person is in the text: by any of their names (any case), or by the first name of their main name (the
 * first one given), capitalized, since "Lena" is how a story says "Lena Park".
 */
export function personNamedIn(text, names) {
    if (namedIn(text, names)) return true;
    const first = firstName(names[0]);
    return !!first && new RegExp(`(?<![\p{L}\p{N}])${first}(?![\p{L}\p{N}])`, 'u').test(String(text || ''));
}

/** Every name a person goes by, for display: "Sasha (also Unit 114)". */
export function akaOf(ledger, name) {
    const canon = aliasResolver(ledger);
    const names = (ledger?.aliases || []).filter(a => canon(a.name) === canon(name)).flatMap(a => [a.name, ...a.aka]);
    return [...new Set(names)].filter(n => lc(n) !== lc(name));
}

const LEDGER_CORE = `You maintain the Body Ledger for an adult roleplay in which minds leave their own bodies and inhabit others (possession, multipossession, skinsuits, hive minds, copies, swaps). The ledger lists:
- bodies: every body that is NOT currently driven by its own mind, every empty or vacated body, every body worn as a skin, and every mind that is outside its own body;
- every character shown or stated to hold such a power, and what the power is.
A body driven by its own mind again leaves the body list. People who are simply themselves in their own bodies are never listed, and neither is anyone whose mind was changed (hypnosis, mind control and the like) while they still drive their own body: this ledger is only about who is in which body.

Evidence. Add or change a row only when the messages plainly show a mind entering, leaving or switching bodies, or say so outright. Being near someone with powers, or touched, grabbed, spoken to, looked at, wanted or mentioned by them, is NOT being possessed. A character who acts on their own, speaks for themselves or shows their own feelings is in their own body. When in doubt, leave the ledger as it is.

Fields for each body:
- body: the body's own name, as the story uses it (for a mind with no body, use "none")
- pronouns: the BODY's own pronouns, e.g. "she/her"
- driver: the name of the mind currently driving it, or "" if nobody is driving it (an empty body)
- driver_pronouns: the DRIVING MIND's own pronouns, e.g. "he/him"
- how: the mechanism in a word or two: possession, multipossession, skinsuit, hive mind, copy, swap. A body overwritten by a copy has the original's name as driver and how "copy"
- host: where the body's own mind is and what has become of it, in a few words, only as the messages or the card actually show it. Be specific, never a bare "gone" or "out": say whether it is erased for good, pushed out for now (and where it is: "pushed out, drifting nearby", "in Sam's old body"), switched off until the rider leaves, asleep inside, or awake inside and powerless. If they don't show it, leave it "". Never guess, and never assume the host is awake or aware.
- notes: a short phrase: what the body is wearing and where it is. Lasting facts only, never a momentary action ("holding a cup", "laughing")
- doing: what the body is busy with right now, an ongoing activity in a few words ("calc homework", "driving to work", "asleep"), or "" if nothing in particular. Keep it current: when the messages show the body moving on to something else, change it
- user_knows: "yes" if {{user}} is the driver, has been told about this takeover, has seen it happen, or the card or opening establishes that {{user}} knows about it; "no" if it is being kept from {{user}}, or happened where {{user}} wasn't and nobody has told them. Knowing that someone has a power is not knowing each time they use it. Once "yes", it stays "yes".

Aliases: anyone the story calls by more than one name (a code name or unit number, a handle, a host number, a nickname, a real name behind a persona) is listed once with every name, e.g. {"name":"Sasha","aka":["Unit 114"]}. In body and driver fields, use the name the story uses most.

Own bodies: a mind that runs other bodies while still in its own (multipossession, a hive's original mind) gets one "own" entry for that own body, {"who": the mind's name, "doing": as above, "notes": what it is wearing and where it is}, kept current the same way whenever that body moves or does something new. Nobody else gets one.

Rules:
- Change only what the new messages clearly establish.
- A mind drives one body at a time unless the story shows it running several at once. When a driver moves into a new body, the body they left is no longer theirs: it is empty (driver "") or back with its own mind (remove it), whichever the messages show.
- A row stays until the messages show it ending: the driver leaving the body, being forced out or letting it go, or the body's own mind back in control. A scene that moves somewhere else, a body nobody mentions for a while, or the driver busy in another body ends nothing.
- Use each character's name as the story does. The player's character is called {{user}}.
- Pronouns come from the story or the card. If a body's sex is plain from the text (breasts, cock, "the girl"), use it.`;

/** First build: the whole ledger. */
export const LEDGER_SYSTEM = `${LEDGER_CORE}
- Copy everything that didn't change exactly as it was.
Answer with the complete ledger as JSON and nothing else, in exactly this shape:
{"bodies":[{"body":"","pronouns":"","driver":"","driver_pronouns":"","how":"","host":"","notes":"","doing":"","user_knows":"yes"}],"own":[{"who":"","doing":"","notes":""}],"powers":[{"who":"","power":""}],"aliases":[{"name":"","aka":[""]}]}`;

// Every later update: only the changes. Rewriting a dozen-body ledger every reply took a 26B local model 7.5 s; most replies
// change nothing or one row, which is well under a second of output.
export const LEDGER_UPDATE_SYSTEM = `${LEDGER_CORE}
Answer with ONLY what changed, as JSON and nothing else, in this shape, leaving out any part with nothing in it:
{"set":[{"body":"","pronouns":"","driver":"","driver_pronouns":"","how":"","host":"","notes":"","doing":"","user_knows":"yes"}],"remove":["body name"],"own":{"set":[{"who":"","doing":"","notes":""}],"remove":["who"]},"powers":{"set":[{"who":"","power":""}],"remove":["who"]},"aliases":[{"name":"","aka":[""]}]}
- set: each body that is new or whose row changed, with all its fields.
- remove: each body whose driver the new messages show leaving (its own mind drives it again), by name; for a mind with no body, the mind's name.
- own: own-body entries that are new or changed (a new place or a new activity counts); remove one when that mind no longer runs other bodies.
- aliases: only new names.
If nothing changed, answer {}`;

const clip = (s, n) => { s = String(s ?? ''); return s.length > n ? s.slice(0, n) + ' …' : s; };

/**
 * @param {object} p
 * @param {object} p.ledger      current ledger (or empty)
 * @param {{name:string, text:string}[]} p.messages  newest messages, oldest first
 * @param {string} p.userName
 * @param {string[]} [p.modes]
 * @param {string} [p.card]      character card text, for a first build
 * @param {string} [p.persona]
 * @param {boolean} [p.update]   answer with only the changes (every update after the first build)
 * @param {{name:string, text:string}[]} [p.context]  the exchange before the new messages, already reflected in the
 *                               ledger: it tells the model who "you" is and who was where, so a mention isn't misread
 * @param {string[]} [p.rules]   the card's rules that bear on the ledger (rules-core compileRules().ledger), every update
 */
export function buildLedgerMessages({ ledger, messages, userName, userPronouns = '', modes = [], card = '', persona = '', update = false, context = [], rules = [] }) {
    const sys = (update ? LEDGER_UPDATE_SYSTEM : LEDGER_SYSTEM).replaceAll('{{user}}', userName || 'the player');
    const parts = [];
    if (card) parts.push(`Character card (background only; the chat decides the current state):\n${clip(card, 3000)}`);
    if (persona) parts.push(`${userName}'s persona:\n${clip(persona, 800)}`);
    if (userPronouns) parts.push(`${userName} (the player) goes by ${userPronouns}: the driver_pronouns of any body ${userName} drives.`);
    if (modes.length) parts.push(`Mechanics this story can use (possible, not necessarily happening): ${modes.join(', ')}.`);
    const keepsOwn = modes.filter(m => KEEPS_OWN_BODY.includes(m));
    if (keepsOwn.length) parts.push(`With ${list(keepsOwn)}, one mind runs several bodies at once, and taking a new body adds it: the mind keeps every body it already had, its own included, unless the messages show it leaving one. Its own body stays off the body list while it still drives it (it gets an "own" entry instead); never list it as empty just because the mind took someone else, and never take a row off because the scene is following its own body or another of its bodies. Such a ride's how is ${keepsOwn.map(m => `"${lc(m)}"`).join(' or ')}, whichever the story shows.`);
    // Only in a one-body story does a driver seen as themselves mean they left. (In a multipossession chat, the
    // possessor cooking dinner in his own body took the other bodies off the ledger.)
    else if (isSingleBody(modes)) parts.push('In this story a mind drives one body at a time, so a driver shown living as themselves in their own body (their own home, their own name and features) has left the body they were in: remove that row.');
    // In a swap each body keeps its own name and home while the other mind drives it, so "Ben at Ben's house" is still
    // Ana inside; the one-body rule above would read that as Ben back home.
    if (modes.includes('Body Swap')) parts.push('With Body Swap, two minds trade bodies: each swapped body is driven by the other\'s mind (how "swap"), and the story keeps calling each body by its own name, in its own home and life. So a swapped body seen under its own name is still swapped; the swap ends, for both rows, only when the messages show it undone.');
    if (rules.length) parts.push(`The card's own rules, which always hold in this story:\n${rules.map(r => `- ${r}`).join('\n')}`);
    parts.push(`Current ledger:\n${JSON.stringify(normalizeLedger(ledger || EMPTY_LEDGER))}`);
    if (context.length) parts.push('Earlier messages, for context only (the ledger already reflects them):\n' + context.map(m => `### ${m.name}\n${clip(m.text, 1500)}`).join('\n\n'));
    parts.push((context.length ? 'New messages to apply' : 'Newest messages') + ', oldest first:\n' + messages.map(m => `### ${m.name}\n${clip(m.text, 2500)}`).join('\n\n'));
    parts.push(update ? 'Now output only what changed, as JSON, or {} if nothing did.' : 'Now output the complete updated ledger as JSON.');
    return [{ role: 'system', content: sys }, { role: 'user', content: parts.join('\n\n') }];
}

/**
 * The first complete JSON object in a response. Local models sometimes keep talking after the answer ("Wait, I need to
 * follow the rules…"), so read up to where the first object closes rather than to the last brace in the text.
 */
function firstJson(text, open = '{') {
    const s = String(text || '');
    const close = open === '[' ? ']' : '}';
    // An answer cut off partway (a model that thinks first can spend the limit) has an object that never closes: it's
    // unreadable, so the caller asks again with room, rather than taking a complete piece from inside it as the answer
    // (a cut-off World update was read as its first thing and saved as empty notes, 2026-10-28).
    for (let a = s.indexOf(open); a >= 0; a = s.indexOf(open, a + 1)) {
        let depth = 0, inStr = false, closed = false;
        for (let i = a; i < s.length; i++) {
            const c = s[i];
            if (inStr) { if (c === '\\') i++; else if (c === '"') inStr = false; continue; }
            if (c === '"') inStr = true;
            else if (c === open) depth++;
            else if (c === close && --depth === 0) {
                closed = true;
                try { return JSON.parse(s.slice(a, i + 1)); } catch { break; }
            }
        }
        if (!closed) return null;
    }
    return null;
}

/** A whole ledger from a model response. Returns null if it can't be parsed. */
export function parseLedger(text) {
    const j = firstJson(text);
    if (!j || (!Array.isArray(j.bodies) && !Array.isArray(j.powers))) return null;
    return normalizeLedger(j);
}

const FIELDS = ['body', 'pronouns', 'driver', 'driver_pronouns', 'how', 'host', 'notes', 'doing', 'user_knows'];
// On a row already in the ledger, an empty string in these is the update template echoed back, never a change.
const KEEP_WHEN_EMPTY = new Set(['body', 'pronouns', 'driver', 'driver_pronouns', 'how', 'user_knows']);
const listOf = v => (Array.isArray(v) ? v : v == null ? [] : [v]);

/**
 * Apply a changes-only answer to a ledger. Rows are matched by body name (or by mind, for a mind with no body),
 * through aliases. A set row replaces only the fields it gives, and once the player knows, they keep knowing.
 */
export function applyLedgerDiff(ledger, diff) {
    const base = normalizeLedger(ledger);
    if (!diff || typeof diff !== 'object') return base;
    const aliases = normalizeAliases([...base.aliases, ...listOf(diff.aliases)]);
    const canon = aliasResolver({ aliases });
    const noBody = b => !b.body || lc(b.body) === 'none';
    const rowKey = b => (noBody(b) ? 'm:' + canon(b.driver) : 'b:' + canon(b.body));
    const nameOf = n => (typeof n === 'string' ? n : n?.body || n?.name || n?.driver || n?.who || '');

    const gone = new Set(listOf(diff.remove ?? diff.removed ?? diff.delete).map(n => canon(nameOf(n))).filter(Boolean));
    let bodies = base.bodies.filter(b => !gone.has(canon(noBody(b) ? b.driver : b.body)));
    // A whole ledger sent during an update is read as changes: rows it gives are set, rows it leaves out stay.
    // A model sometimes answers with a partial "whole" ledger, and replacing with it wiped real rows.
    for (const r of listOf(diff.set ?? diff.add ?? diff.update ?? diff.changed ?? diff.bodies)) {
        if (!r || typeof r !== 'object' || (!r.body && !r.driver)) continue;
        const i = bodies.findIndex(b => rowKey(b) === rowKey(r));
        if (i < 0) {
            // A new row with nobody driving and nothing said about the host carries no information: noise.
            if (!noBody(r) && !str(r.driver) && !str(r.host)) continue;
            bodies.push(r);
            continue;
        }
        const merged = { ...bodies[i] };
        for (const f of FIELDS) {
            if (r[f] === undefined || r[f] === null) continue;
            if (f === 'user_knows' && bodies[i].user_knows === 'yes') continue;
            // It would wipe stored pronouns, the driver or the kind of ride. Notes, what the body is doing and the
            // host's state can still be cleared on purpose.
            if (KEEP_WHEN_EMPTY.has(f) && !str(r[f])) continue;
            merged[f] = r[f];
        }
        bodies[i] = merged;
    }

    const p = diff.powers;
    const pSet = Array.isArray(p) ? p : listOf(p?.set ?? p?.add);
    const pGone = new Set(listOf(Array.isArray(p) ? [] : p?.remove).map(n => canon(nameOf(n))));
    let powers = base.powers.filter(x => !pGone.has(canon(x.who)));
    for (const x of pSet) {
        if (!x?.who || !x?.power) continue;
        const i = powers.findIndex(y => canon(y.who) === canon(x.who));
        if (i < 0) powers.push(x); else powers[i] = { ...powers[i], power: x.power };
    }

    const o = diff.own;
    const oSet = Array.isArray(o) ? o : listOf(o?.set ?? o?.add);
    const oGone = new Set(listOf(Array.isArray(o) ? [] : o?.remove).map(n => canon(nameOf(n))));
    const own = base.own.filter(x => !oGone.has(canon(x.who)));
    for (const x of oSet) {
        if (!x?.who) continue;
        const i = own.findIndex(y => canon(y.who) === canon(x.who));
        const given = Object.fromEntries(['doing', 'notes'].filter(k => x[k] != null).map(k => [k, x[k]]));
        if (i < 0) own.push({ who: x.who, ...given }); else own[i] = { ...own[i], ...given };
    }

    // A minds entry in the answer is only kept when it's really a body row filed in the wrong place (normalizeLedger).
    const d = diff.minds;
    const minds = Array.isArray(d) ? d : listOf(d?.set ?? d?.add);
    return normalizeLedger({ bodies, own, minds, powers, aliases });
}

/**
 * Read an update answer against the current ledger: a changes-only object, {} for no change, or a whole ledger
 * if the model sent one anyway. Returns null if it can't be read.
 */
export function parseLedgerUpdate(text, current) {
    const j = firstJson(text);
    if (!j) return /^\s*(\{\s*\}|none|no changes?\.?)\s*$/i.test(String(text || '')) ? normalizeLedger(current) : null;
    // Something with none of an update's parts isn't an update (a piece of one, or the wrong shape): unreadable.
    if (!Array.isArray(j) && Object.keys(j).length && !['set', 'add', 'update', 'changed', 'bodies', 'remove', 'removed', 'delete', 'aliases', 'powers', 'own'].some(k => k in j)) return null;
    return applyLedgerDiff(current, j);
}

// ------------------------------------------------------------------ second look at new possessions
// The update model over-reads: someone grabbed, spoken to or merely present near a possessor got listed as
// possessed. A yes/no question about one specific pair is much easier than open extraction, and new possessions
// are rare, so each one gets checked before it's kept.

/** Possessions in `next` that `prev` didn't have. */
export function newRides(prev, next) {
    const key = pairKeyWith(aliasResolver(prev, next));
    const had = new Set(rides(prev).map(b => key(b.driver, b.body)));
    return rides(next).filter(b => !had.has(key(b.driver, b.body)));
}

export const RIDE_CHECK_SYSTEM = `You check one claim about a roleplay: that a particular mind has taken over a particular person's body and is driving it (possession, wearing them as a skin, a hive taking them, a copy overwriting them).
Answer YES if the messages show it or clearly imply it: the mind going into them; the person jolting, blanking or going still and then acting for that mind; the possessor talking about being in them or speaking through them; the narration saying so. A mind that can run several bodies can be in this one while its own body sits somewhere else.
Answer NO if the only link is being near, touched, grabbed, held, talked to, looked at, threatened, wanted or mentioned, or the person doing what they're told out of fear or their own choice. When it's truly unclear, answer NO.
Answer YES or NO on the first line, then quote the words that decide it.`;

export function buildRideCheckMessages(ride, messages, context = [], userName = 'the player', { ledger = null, modes = [] } = {}) {
    const show = xs => xs.map(m => `### ${m.name}\n${clip(m.text, 2500)}`).join('\n\n');
    const canon = aliasResolver(ledger);
    const already = ledger ? rides(ledger).filter(b => canon(b.driver) === canon(ride.driver)).map(b => b.body) : [];
    const known = [
        modes.length ? `Mechanics this story can use: ${modes.join(', ')}.` : '',
        already.length ? `Already known: ${ride.driver} is driving ${list(already)}.` : '',
        `The player's character is ${userName}; "you" in the narration is ${userName}, or whoever is driving ${userName}'s body.`,
    ].filter(Boolean).join('\n');
    // In a one-body story, a mind that already has a body can only take a new one by leaving the old: check for
    // that, the stronger claim. (Unchecked, a quote about the current body was taken as proof of a move.)
    const claim = already.length && isSingleBody(modes)
        ? `${ride.driver}'s mind has left ${list(already)} and is now inside ${ride.body}'s body, driving it.`
        : `${ride.driver}'s mind is now inside ${ride.body}'s body, driving it.`;
    return [
        { role: 'system', content: RIDE_CHECK_SYSTEM },
        { role: 'user', content: `${context.length ? `Earlier messages:\n${show(context)}\n\n` : ''}New messages:\n${show(messages)}\n\n${known}\nClaim: ${claim}\nIs the claim shown? YES or NO.` },
    ];
}

// Modes that let one mind drive several bodies at once. Without any of them, taking a new body means leaving the
// old one (a case from testing: the ledger kept the old body "driven by" a mind after it jumped into a new one).
const MULTI_MODES = ['Multipossession', 'Hive Mind', 'Propagation', 'Puppetry'];
export const isSingleBody = (modes = []) => modes.length > 0 && !modes.some(m => MULTI_MODES.includes(m));
// Modes where the mind's own body stays one of the set. (A Multipossession chat had the player's body "go slack",
// and the ledger, labeling the ride plain "possession", had no way to say otherwise.)
const KEEPS_OWN_BODY = ['Multipossession', 'Hive Mind'];

/**
 * A ride the model labeled plain "possession" is a multipossession when that mode is on, a hive mind in a story whose
 * only occupancy mode is Hive Mind, and a swap in one whose only one is Body Swap. The label is what tells the rest of
 * the ledger the mind kept its own body (or, for a swap, that its own body has the other mind in it).
 */
export function labelMultiRides(ledger, modes = []) {
    const l = normalizeLedger(ledger);
    const only = m => modes.includes(m) && !modes.includes('Possession');
    const label = modes.includes('Multipossession') ? 'multipossession' : only('Hive Mind') ? 'hive mind' : only('Body Swap') ? 'swap' : '';
    if (!label) return l;
    return { ...l, bodies: l.bodies.map(b => (b.driver && b.body && /^\s*(possession|possessed)?\s*$/i.test(b.how) ? { ...b, how: label } : b)) };
}

/** With no multi-body mode picked, a mind that takes a new body has left its old one: that body is now empty. */
export function oneBodyAtATime(prev, next, modes = []) {
    if (!isSingleBody(modes)) return normalizeLedger(next);
    const canon = aliasResolver(prev, next);
    const moved = new Map(newRides(prev, next).map(r => [canon(r.driver), canon(r.body)]));
    if (!moved.size) return normalizeLedger(next);
    const bodies = normalizeLedger(next).bodies.map(b => (b.driver && moved.has(canon(b.driver)) && moved.get(canon(b.driver)) !== canon(b.body)
        ? { ...b, driver: '', driver_pronouns: '' } : b));
    return normalizeLedger({ ...next, bodies });
}

export const parseRideCheck = text => /^[\s*"'`]*yes\b/i.test(String(text || ''));

// "Did the mind move?" as a yes/no was approved on stray quotes (a corpse's thumbprint, the line where the mind
// LEFT that body). Picking where the mind is now, from a short list, is a question even a small model gets right.
export const WHERE_SYSTEM = `You read a roleplay and say where one mind is at the end of the new messages: which body it is inside and driving. Go by what the messages show happening, not by who is mentioned, touched or talked about. Answer with exactly one option from the list, copied as written, on the first line.`;

/** Options: the bodies the mind drives now, the claimed new body, its own body, and "unclear". */
export function buildWhereMessages(ride, current, messages, context = [], userName = 'the player') {
    const show = xs => xs.map(m => `### ${m.name}\n${clip(m.text, 2500)}`).join('\n\n');
    const options = [...new Set([...current, ride.body])].map(b => `${b}'s body`).concat([`${ride.driver}'s own body`, 'unclear']);
    return {
        options,
        messages: [
            { role: 'system', content: WHERE_SYSTEM },
            { role: 'user', content: `${context.length ? `Earlier messages:\n${show(context)}\n\n` : ''}New messages:\n${show(messages)}\n\nThe player's character is ${userName}; "you" in the narration is ${userName}, or whoever is driving ${userName}'s body.\nBefore these messages, ${ride.driver}'s mind was in ${list(current)}'s body.\nAt the end of the new messages, where is ${ride.driver}'s mind?\n${options.map(o => `- ${o}`).join('\n')}` },
        ],
    };
}

/** The option the answer names (first match on the first line), or null. */
export function parseWhere(text, options) {
    const first = (String(text || '').split('\n').find(l => l.trim()) || '').toLowerCase();
    const key = o => o.toLowerCase().replace(/'s (?:own )?body$/, '');
    const esc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    // Whole names only, so "Ann" never matches inside "Anna"; the earliest in the answer wins, and the longer name on
    // a tie. "Sam's own body" answers to "Sam" as well.
    const hits = options.map(o => [o, first.search(new RegExp(`\\b${esc(key(o))}\\b`))]).filter(([, i]) => i >= 0)
        .sort((a, b) => a[1] - b[1] || key(b[0]).length - key(a[0]).length);
    return hits.length ? hits[0][0] : null;
}

/**
 * Second look at every new possession before it's kept; `ask(messages, maxTokens)` returns the model's text.
 * In a one-body story, a mind that already has a body gets the "where is it now?" question; otherwise yes/no.
 * Then, in a one-body story, the body a mind moved out of is left empty.
 */
export async function verifyNewRides(prev, next, { messages, context = [], userName = 'the player', modes = [] }, ask) {
    const canon = aliasResolver(prev, next);
    const rejected = [], log = [];
    for (const ride of newRides(prev, next)) {
        const current = rides(prev).filter(b => canon(b.driver) === canon(ride.driver)).map(b => b.body);
        let ok, answer;
        if (current.length && isSingleBody(modes)) {
            const w = buildWhereMessages(ride, current, messages, context, userName);
            answer = await ask(w.messages, 60);
            ok = parseWhere(answer, w.options) === `${ride.body}'s body`;
        } else {
            answer = await ask(buildRideCheckMessages(ride, messages, context, userName, { ledger: prev, modes }), 120);
            ok = parseRideCheck(answer);
        }
        log.push({ ride: `${ride.driver} → ${ride.body}`, kept: ok, answer: String(answer).replace(/\s+/g, ' ').slice(0, 160) });
        if (!ok) rejected.push(ride);
    }
    return { ledger: oneBodyAtATime(prev, dropRides(prev, next, rejected), modes), rejected, log };
}

/** Undo the rows for rides the check rejected: back to what the previous ledger had for that body, or gone. */
export function dropRides(prev, next, rejected) {
    if (!rejected.length) return normalizeLedger(next);
    const canon = aliasResolver(prev, next);
    const bodyKey = b => canon(b.body);
    const wrong = new Set(rejected.map(bodyKey));
    const before = new Map(normalizeLedger(prev).bodies.map(b => [bodyKey(b), b]));
    const bodies = normalizeLedger(next).bodies.flatMap(b => (!wrong.has(bodyKey(b)) ? [b] : before.has(bodyKey(b)) ? [before.get(bodyKey(b))] : []));
    return normalizeLedger({ ...next, bodies });
}

// ------------------------------------------------------------------ second look at ended possessions
// The other way round: the update model takes rows off when the scene moves on, a body goes unmentioned for a while,
// or (with several bodies) the possessor is busy in their own body. A row only leaves when the messages show it
// ending, so each one that leaves gets a look. If the new messages never name the body or its driver it is simply
// kept; otherwise a yes/no question decides.

export const END_CHECK_SYSTEM = `You check one claim about a roleplay: that a particular mind has stopped driving a particular person's body.
Answer YES only if the new messages show it ending: the mind leaving the body, being forced out or letting it go, or the person's own mind back in control. A passage marked as a release (between %%release%% lines) or as stepping out of a skin (%%shed%%) is exactly that.
Answer NO if the messages simply follow someone else, move to another place, leave the person out, or show the mind busy in another body, its own included. When it's unclear, answer NO.
Answer YES or NO on the first line, then quote the words that decide it.`;

export function buildEndCheckMessages(ride, messages, context = [], userName = 'the player', { modes = [] } = {}) {
    const show = xs => xs.map(m => `### ${m.name}\n${clip(m.text, 2500)}`).join('\n\n');
    const known = [
        modes.length ? `Mechanics this story can use: ${modes.join(', ')}.` : '',
        `The player's character is ${userName}; "you" in the narration is ${userName}, or whoever is driving ${userName}'s body.`,
    ].filter(Boolean).join('\n');
    return [
        { role: 'system', content: END_CHECK_SYSTEM },
        { role: 'user', content: `${context.length ? `Earlier messages:\n${show(context)}\n\n` : ''}New messages:\n${show(messages)}\n\n${known}\nClaim: ${ride.driver}'s mind is no longer driving ${ride.body}'s body.\nIs the claim shown? YES or NO.` },
    ];
}

/** Whether the text names someone: their name, a proper first name, an alias, or "you" for the player. */
function names(text, who, ledger, userName) {
    const canon = aliasResolver(ledger);
    const keys = [who, ...akaOf(ledger, who)].flatMap(n => {
        const s = str(n), first = s.split(' ')[0];
        return /^[A-Z]/.test(first) && first.length > 2 && !/^(The|His|Her|Their|Its)$/.test(first) ? [s, first] : [s];
    });
    if (userName && canon(who) === canon(userName)) keys.push('you', 'your');
    return keys.some(k => k && new RegExp(`\\b${k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(text));
}

/**
 * Second look at every possession that left the ledger; `ask(messages, maxTokens)` as for verifyNewRides. A ride the
 * new messages never touch is put back without asking; otherwise a NO puts it back. In a one-body story, a mind that
 * just took a new body has left the old one, which the where-check already settled, so that isn't asked again.
 */
export async function verifyEndedRides(prev, next, { messages, context = [], userName = 'the player', modes = [] }, ask) {
    const canon = aliasResolver(prev, next);
    const text = messages.map(m => m.text).join('\n');
    const moved = new Set(isSingleBody(modes) ? newRides(prev, next).map(r => canon(r.driver)) : []);
    const kept = [], log = [];
    // The writer marks the moment a possessor lets a body go (%%release%%, or %%shed%% for a skin; on Chub a
    // blockquote under the same title): one that names the body settles it without asking.
    const releases = [
        ...[...text.matchAll(/%%(release|shed)%%([\s\S]*?)(?:%%\/\1%%|$)/gi)].map(m => m[2]),
        ...[...text.matchAll(/^> \*\*◇ (?:release|stepped out) ◇\*\*[ \t]*\n((?:>.*(?:\n|$))*)/gim)].map(m => m[1]),
    ];
    for (const ride of endedRides(prev, next)) {
        if (moved.has(canon(ride.driver))) continue;
        let ended = false, answer = 'neither the body nor its driver is in the new messages';
        if (releases.some(r => names(r, ride.body, prev, userName))) { ended = true; answer = 'a marked release names the body'; }
        else if (names(text, ride.body, prev, userName) || names(text, ride.driver, prev, userName)) {
            answer = await ask(buildEndCheckMessages(ride, messages, context, userName, { modes }), 120);
            ended = parseRideCheck(answer);
        }
        log.push({ ride: `${ride.driver} → ${ride.body}`, ended, answer: String(answer).replace(/\s+/g, ' ').slice(0, 160) });
        if (!ended) kept.push(ride);
    }
    // And the other way: a marked release that names exactly one body still being ridden ends that ride, even when
    // the update kept it. (With two ridden bodies named, the passage could be about either, so it's left alone; and a
    // bare "you" doesn't count here, since second-person narration says it in every passage.)
    let out = keepRides(prev, next, kept);
    for (const r of releases.filter(r => r.trim())) {
        const named = rides(out).filter(b => names(r, b.body, out, null));
        if (named.length !== 1) continue;
        out = normalizeLedger({ ...out, bodies: out.bodies.filter(b => canon(b.body) !== canon(named[0].body)) });
        log.push({ ride: `${named[0].driver} → ${named[0].body}`, ended: true, answer: 'a marked release names only this body' });
    }
    return { ledger: out, kept, log };
}

/** Put back the rows for rides that didn't really end, as the previous ledger had them. */
export function keepRides(prev, next, kept) {
    if (!kept.length) return normalizeLedger(next);
    const canon = aliasResolver(prev, next);
    const back = new Set(kept.map(r => canon(r.body)));
    const before = normalizeLedger(prev).bodies.filter(b => back.has(canon(b.body)));
    const n = normalizeLedger(next);
    return normalizeLedger({ ...n, bodies: [...n.bodies.filter(b => !back.has(canon(b.body))), ...before] });
}

/**
 * One Ledger update, exactly as the extension runs it after a reply: the first build when there's no ledger yet,
 * otherwise a changes-only update with a second look at every new and every ended body change, then the multi-body
 * labels. The evals and the Gym call this too, so they score what play does. `ask(messages, maxTokens)` returns the
 * model's text. An error from the update itself is thrown; the second looks are filters, so if the model can't be
 * reached for one the update is kept as it was. Returns null when the answer can't be read.
 */
export async function ledgerStep({ ledger = null, messages, context = [], userName, userPronouns = '', modes = [], card = '', persona = '', rules = [] }, ask) {
    const first = !ledger;
    const msgs = buildLedgerMessages({
        ledger: ledger || EMPTY_LEDGER, messages, context, userName, userPronouns, modes, rules,
        card: first ? card : '', persona: first ? persona : '',
        update: !first,   // after the first build, only the changes: about 0.5 s instead of 2 s, and it tracks better
    });
    const read = text => (first ? parseLedger(text) : parseLedgerUpdate(text, ledger));
    let answer = await ask(msgs, 900);
    let next = read(answer);
    // A model that thinks before answering can run out of room partway through the JSON (Haiku 5.5 did, 1 reply in 10):
    // one more try with plenty of room. Only then: an answer that ended unreadable would only come back longer.
    if (!next && cutShort(answer)) { answer = await ask(msgs, 4000); next = read(answer); }
    if (!next) return null;
    const log = { answer, added: [], ended: [] };
    if (!first) {
        // Every new body change gets a second look before it's kept (someone merely near the one doing it used to be listed).
        try {
            const v = await verifyNewRides(ledger, next, { messages, context, userName, modes }, ask);
            next = v.ledger; log.added = v.log;
        } catch { /* keep the update as it was */ }
        // And every body that left gets one too: a scene moving on, or the possessor busy in another body, ends nothing.
        try {
            const e = await verifyEndedRides(ledger, next, { messages, context, userName, modes }, ask);
            next = e.ledger; log.ended = e.log;
        } catch { /* as above */ }
    }
    return { ledger: labelMultiRides(next, modes), log };
}

// Modes the Ledger runs for: the ones where a mind inhabits a body that isn't its own. (Mind changes are left to the
// Codex; Puppetry steers a body from outside.) Copy Fidelity and Reverse Vore bring in a mode on this list.
export const LEDGER_MODES = ['Possession', 'Multipossession', 'Skinsuit', 'Hive Mind', 'Reverse Vore', 'Propagation', 'Copy Fidelity', 'Body Swap'];
export const tracksBodies = (modes = []) => modes.some(m => LEDGER_MODES.includes(m));

const same = (a, b) => a.toLowerCase() === b.toLowerCase();

const list = xs => xs.length <= 1 ? xs.join('') : `${xs.slice(0, -1).join(', ')} and ${xs[xs.length - 1]}`;
const MULTI = /multi|hive|network|collective|swarm/i;

/**
 * Minds running more than one body at once (their own included), with the bodies they run: one person in several
 * places. Copies are separate people and puppets empty bodies moved from outside, so neither counts.
 */
export function multiBodyGroups(ledger) {
    const l = normalizeLedger(ledger);
    const canon = aliasResolver(l);
    // A mind's own body with a row of its own (empty, or someone else inside) isn't one it's running.
    const listed = new Set(l.bodies.filter(b => b.body).map(b => canon(b.body)));
    const groups = new Map();
    for (const b of l.bodies) {
        if (!b.driver || !b.body || same(b.body, 'none') || COPY.test(b.how) || PUPPET.test(b.how)) continue;
        const g = groups.get(canon(b.driver)) || { driver: b.driver, bodies: [], ownToo: false, hidden: false };
        g.bodies.push(b.body);
        if (MULTI.test(b.how) && !listed.has(canon(b.driver))) g.ownToo = true;
        if (b.user_knows === 'no') g.hidden = true;
        groups.set(canon(b.driver), g);
    }
    return [...groups.values()].filter(g => g.bodies.length > 1 || g.ownToo);
}

// ------------------------------------------------------------------ quick actions (Possess, Release, Jump)
// Buttons over the message box write the player's move into their message and tell the Ledger at once, so the reply is
// written from the new state and the Ledger never has to work it out from the prose.

/** The line a quick action puts in the player's message. `multi`: the player keeps their own body (Multipossession). */
export function intentLine({ kind, from = '', to = '' }, { multi = false, hive = false } = {}) {
    if (kind === 'possess') return hive ? `*I absorb ${to} into the hive.*` : `*I possess ${to}.*`;
    if (kind === 'release') return hive ? `*I release ${from} from the hive.*` : multi ? `*I release ${from}.*` : `*I release ${from} and return to my own body.*`;
    if (kind === 'jump') return `*I leave ${from} and possess ${to}.*`;
    return '';
}

/**
 * The ledger after a quick action: possess `to`, release `from`, or jump from one to the other. One body at a time
 * leaves the player's own body empty (a row of its own); with `multi`, their own body stays theirs and in use. With
 * `hive`, possessing is absorbing someone into the player's hive, and their own body stays theirs too. Once the player
 * drives nobody, their own body's empty row goes: they're back in it.
 */
export function applyIntent(ledger, { kind, from = '', to = '' }, { userName, userPronouns = '', multi = false, hive = false } = {}) {
    multi ||= hive;
    const l = normalizeLedger(ledger);
    const canon = aliasResolver(l);
    const me = canon(userName);
    const mine = b => b.driver && canon(b.driver) === me;
    let bodies = [...l.bodies];
    if ((kind === 'release' || kind === 'jump') && from) bodies = bodies.filter(b => !(b.body && canon(b.body) === canon(from) && mine(b)));
    if ((kind === 'possess' || kind === 'jump') && to && canon(to) !== me) {
        const was = bodies.find(b => b.body && canon(b.body) === canon(to));
        bodies = bodies.filter(b => b !== was);
        bodies.push({ body: was?.body || to, pronouns: was?.pronouns || '', driver: userName, driver_pronouns: userPronouns, how: hive ? 'hive mind' : multi ? 'multipossession' : 'possession',
            host: was?.host || '', notes: was?.notes || '', doing: '', user_knows: 'yes' });
        if (!multi && !bodies.some(b => b.body && canon(b.body) === me)) bodies.push({ body: userName, pronouns: userPronouns, driver: '', driver_pronouns: '', how: '', host: '', notes: '', doing: '', user_knows: 'yes' });
    }
    if (!bodies.some(b => mine(b) && b.body && canon(b.body) !== me)) bodies = bodies.filter(b => !(b.body && canon(b.body) === me && !b.driver));
    return normalizeLedger({ ...l, bodies });
}

/** Every body `name` is running right now, their own listed as `name`; empty unless it's more than one. */
export function bodiesRunBy(ledger, name) {
    return rosterOf(ledger, name).map(r => r.name);
}

/**
 * The bodies `name` directs right now, with what each is doing and where it is: {name, own, doing, notes}. Hosts and
 * hive bodies share their mind, puppets are moved from outside, and the mind's own body counts while it keeps it
 * alongside the others. Copies are their own people and never count. Empty unless it's more than one.
 */
export function rosterOf(ledger, name) {
    const l = normalizeLedger(ledger);
    const canon = aliasResolver(l);
    const mine = l.bodies.filter(b => b.driver && b.body && !same(b.body, 'none') && canon(b.driver) === canon(name) && !COPY.test(b.how));
    const listed = new Set(l.bodies.filter(b => b.body).map(b => canon(b.body)));
    const ownToo = mine.some(b => MULTI.test(b.how) || PUPPET.test(b.how)) && !listed.has(canon(name));
    if (mine.length + (ownToo ? 1 : 0) < 2) return [];
    const own = l.own.find(o => canon(o.who) === canon(name)) || {};
    return [
        ...(ownToo ? [{ name, own: true, doing: own.doing || '', notes: own.notes || '' }] : []),
        ...mine.map(b => ({ name: b.body, own: false, doing: b.doing, notes: b.notes })),
    ];
}

// A swap names people by who they are, not by the body (the Body Swap entry), so the naming rules, the pronoun check
// and the pointer cut all leave swapped bodies out. A hidden swap is still written as each body's owner.
export const isSwap = b => /swap/i.test(b?.how || '');
const knownSwap = b => isSwap(b) && b.body && b.driver && b.user_knows !== 'no';
const pronSub = p => ({ she: 'she', he: 'he' }[lc(p).split('/')[0]] || 'they');
const upFirst = s => String(s).charAt(0).toUpperCase() + String(s).slice(1);

// Each mechanism in its own words. A generic "driven by" on every row, every reply, read as someone operating a
// body from outside and pulled scenes toward puppetry.
const PLAIN_HOW = /^\s*(possession|possessed|skinsuit|skin|worn|hive( mind)?|copy|propagation|puppetry|puppet|swap|body swap|)\s*$/i;
function rideVerb(how) {
    const h = lc(how);
    if (/skin|worn/.test(h)) return 'worn as a skin by';
    if (/hive/.test(h)) return 'absorbed into the hive of';
    if (/cop(y|ied)|propagat|overwrit/.test(h)) return 'overwritten by a copy of';
    if (/puppet/.test(h)) return 'puppeted from outside by';
    if (/swap/.test(h)) return 'swapped, now home to';
    return 'possessed by';
}

/**
 * Which of `names` the player's message gives a line of its own ("[Kayla] …" or "Kayla: …" at the start of a line),
 * and whether it also has lines with no name.
 */
export function linesFor(text, names) {
    const byKey = new Map(names.map(n => [lc(n), n]));
    const given = new Set();
    let untagged = false;
    for (const line of String(text || '').split('\n')) {
        if (!line.trim()) continue;
        const m = /^\s*\[([^\]\n]+)\]\s*(\S.*)?$/.exec(line) || /^\s*([^:\n[\]]{1,40}):\s*(\S.*)?$/.exec(line);
        const name = m && byKey.get(lc(m[1]));
        if (name) { if (m[2]) given.add(name); } else untagged = true;
    }
    return { given: names.filter(n => given.has(n)), untagged };
}

/**
 * One message from the lanes (a box per body): the message box's own text, for the player as a whole, first, then a
 * [Name] line for each body with something in its lane. A lane's line breaks become spaces: a body's line is one line.
 * A lane left empty sends nothing, and the turn line tells the writer that body does nothing new.
 */
export function joinLanes(general, lanes) {
    const out = [String(general || '').trim()].filter(Boolean);
    for (const { name, text } of lanes) {
        const t = String(text || '').replace(/\s*\n\s*/g, ' ').trim();
        if (t) out.push(`[${name}] ${t}`);
    }
    return out.join('\n');
}

/**
 * The player's bodies by name for this turn: the ones their message gave a line and the ones it didn't. A general
 * rule lost to a scene that pulled the other way (a customer waiting at an absorbed barista's register); names hold.
 */
function turnLine(roster, userName, lastUserText) {
    const names = roster.map(r => r.name);
    const { given, untagged } = linesFor(lastUserText, names);
    if (!given.length) return '';
    const idle = roster.filter(r => !given.includes(r.name)).map(r => (r.own ? `${userName}'s own body` : r.name));
    const gave = given.map(n => (lc(n) === lc(userName) ? `${userName}'s own body` : n));
    if (!idle.length) return `This turn ${userName} wrote a line for every one of their bodies: write each doing only that.`;
    const one = idle.length === 1;
    return `This turn ${userName} wrote lines for ${list(gave)} and nothing for ${list(idle)}${untagged ? ' (unless a line with no name plainly includes them)' : ''}. `
        + `${list(idle)} ${one ? 'does' : 'do'} nothing new and ${one ? 'says' : 'say'} nothing: if anyone speaks to or waits on ${one ? idle[0] : 'any of them'}, write that person and stop there, leaving the answer to ${userName}.`;
}

/**
 * The text injected into the prompt (depth 1). Empty string when there is nothing to say.
 * Host sheets ride along: `sheets` maps a body's lowercased name to the short text on who that person is in their own
 * life (persona-core.js), given under the body's row, and `back` lists people whose bodies were taken and are theirs
 * again but who are still in the scene ({ body, text }), since the writer plays them again and needs them most then.
 */
// scene: the last few messages. Given, a taken body's sheet goes in only while the body is in the scene (named there, by
// any of its names); its row always does. Left out (the /wh-ledger readout), every sheet goes in.
export function renderLedger(ledger, userName = '{{user}}', { lastUserText = '', sheets = new Map(), back = [], scene = null, userPronouns = '' } = {}) {
    const l = normalizeLedger(ledger);
    if (isEmptyLedger(l) && !back.length) return '';
    const lines = [];
    const sheetOf = body => (body && (scene == null || personNamedIn(scene, [body, ...akaOf(l, body)])) ? sheets.get(lc(body)) : '');
    const who = (body, text) => `  Who ${body} is in their own life: ${String(text).replace(/\s*\n\s*/g, ' ')}`;
    const hidden = [];
    const canon = aliasResolver(l);
    // What the player's bodies are busy with is for the roster only: given to the writer, it was an invitation to
    // write those bodies doing things the player never wrote.
    const players = d => d && canon(d) === canon(userName);
    for (const b of l.bodies) {
        const body = b.body && b.body.toLowerCase() !== 'none' ? b.body : null;
        const bodyTag = body ? `${body}${b.pronouns ? ` (${b.pronouns})` : ''}` : null;
        // The player's own pronouns, from Worldhopper's setting, where the Ledger left them out.
        const driverPron = b.driver_pronouns || (players(b.driver) ? userPronouns : '');
        const driverTag = b.driver ? `${b.driver}${driverPron ? ` (${driverPron})` : ''}` : null;
        let line;
        if (!bodyTag) line = `${driverTag}: a mind with no body right now`;
        else if (driverTag && !same(b.driver, body)) line = `${bodyTag}: ${rideVerb(b.how)} ${driverTag}${PLAIN_HOW.test(b.how) ? '' : ` (${b.how})`}`;
        else line = `${bodyTag}: empty, nobody inside${b.how ? ` (${b.how})` : ''}`;
        if (bodyTag && b.host) line += `. ${body}'s own mind: ${b.host}`;
        if (b.notes) line += `. ${upFirst(b.notes)}`;
        if (b.doing && !players(b.driver)) line += `. Busy with: ${b.doing}`;
        if (b.user_knows === 'no' && body && b.driver) { line += `. HIDDEN from ${userName}`; hidden.push(b); }
        lines.push(`- ${line}.`.replace(/\.\.$/, '.'));
        if (body && b.driver && !same(b.driver, body) && sheetOf(body)) lines.push(who(body, sheetOf(body)));
    }
    const rules = [];
    const roster = rosterOf(l, userName);
    const ownLine = who => {
        const own = l.own.find(o => canon(o.who) === canon(who));
        const busy = own?.doing && !players(who) ? `. Busy with: ${own.doing}` : '';
        lines.push(`- ${who}'s own body: still ${who}'s, awake and in use${own?.notes ? `. ${upFirst(own.notes)}` : ''}${busy}.`.replace(/\.\.$/, '.'));
    };
    const groups = multiBodyGroups(l);
    for (const g of groups) if (g.ownToo) ownLine(g.driver);
    if (roster.some(r => r.own) && !groups.some(g => g.ownToo && players(g.driver))) ownLine(userName);
    for (const g of groups) {
        const bodies = [...g.bodies, ...(g.ownToo ? [`${g.driver}'s own body`] : [])];
        const independent = `Each body does its own thing, the way a drummer's limbs play different parts: never the same action at once, never in sync, never mirroring each other (only a mind new to the ability slips into that).`;
        if (g.hidden) {
            rules.push(`${list(bodies)} are all ${g.driver}, but ${userName} doesn't know. Around ${userName} they act like the separate people they appear to be, naturally or a little awkwardly, since one person is playing every part, and narration never shows the link. ${independent}`);
        } else {
            rules.push(`${list(bodies)} are all ${g.driver}: one person in several places. They touch, pleasure, look at and talk about each other freely, since that is one person enjoying their own bodies, but they never converse with each other as if they were separate people, except as staged talk in front of someone who doesn't know. ${independent}`);
        }
    }
    // The player's bodies, one or several: "you", and nothing written for them beyond what the player wrote. The rule
    // used to come only with two or more bodies, and the Writer Gym's one-body scenes were where replies acted for the
    // player (2026-11-01). Said once, in plain terms: a "you" line on every row, with the wrong forms quoted ("never
    // 'Kayla leans'"), primed the very forms it named. Copies are their own people and never count.
    const mine = [...new Set(l.bodies.filter(b => b.body && !same(b.body, 'none') && players(b.driver) && !same(b.body, b.driver) && !COPY.test(b.how)).map(b => b.body))];
    if (mine.length || roster.length) {
        const names = [...(roster.length ? roster.filter(r => !r.own).map(r => r.name) : mine), ...(roster.some(r => r.own) ? [`${userName}'s own body`] : [])];
        const one = names.length === 1;
        const ex = mine[0] || names[0];
        rules.push(`${list(names)} ${one ? 'is' : 'are'} ${userName}'s to play. In the narration ${one ? 'that body is' : 'each of them is'} "you": your hands, your face, what you do, how people look at you, even where earlier replies named ${one ? 'it' : 'them'} in the third person. ${one ? 'The' : 'A'} body's name only says which body ("as ${ex}, you…") or whose things they are: ${ex}'s own things stay ${ex}'s ("${ex}'s phone"), and only ${userName}'s own things are "your". `
            + (one ? `Write nothing of what ${ex} does, says, thinks or feels beyond what ${userName} wrote, exactly as you never write ${userName}. If someone speaks to ${ex} or waits on an answer ${userName} didn't give, write that person and stop, leaving the answer to ${userName}.`
                : `Write nothing of what they do, say, think or feel beyond what ${userName} wrote for each, exactly as you never write ${userName}; a body ${userName} gave nothing this turn does nothing new. If someone speaks to one of them or waits on an answer ${userName} didn't give, write that person and stop, leaving the answer to ${userName}.`));
        const turn = roster.length ? turnLine(roster, userName, lastUserText) : '';
        if (turn) rules.push(turn);
    }
    const swapped = l.bodies.filter(knownSwap);
    if (swapped.length) {
        const people = [...new Set(swapped.map(b => b.driver))];
        const yours = swapped.find(b => players(b.driver));
        const other = swapped.find(b => !players(b.driver));
        if (yours) {
            // The player's own example in the second person: "Rika reaches out with Rowan's hand" taught the writer to
            // name the player in a swap, against the "you" rule above.
            const poss = { she: 'her', he: 'his' }[lc(other?.driver_pronouns).split('/')[0]] || 'their';
            const theirs = other ? ` ${other.driver} keeps ${poss} own name and pronouns for what ${pronSub(other.driver_pronouns)} ${pronSub(other.driver_pronouns) === 'they' ? 'do' : 'does'}, say${pronSub(other.driver_pronouns) === 'they' ? '' : 's'} and think${pronSub(other.driver_pronouns) === 'they' ? '' : 's'}, with whose body it is said where that helps ("${other.driver}, in ${players(other.body) ? 'your' : `${other.body}'s`} body, folds ${poss} arms").` : '';
            rules.push(`${list(people)} have swapped bodies. You are in ${yours.body}'s body and stay "you", with whose body it is said where that helps ("you reach out with ${yours.body}'s hand").${theirs} People who don't know about the swap still treat each body as its owner.`);
        } else {
            const ex = swapped[0];
            rules.push(`${list(people)} ${people.length > 1 ? 'have' : 'has'} swapped bodies, and for them the narration follows the person, not the body, so it's always clear who is doing what: each keeps their own name and pronouns for what they do, say and think, and the narration says whose body it is wherever that helps ("${ex.driver} reaches out with ${ex.body}'s hand"). People who don't know about the swap still treat each body as its owner. This replaces the naming above for swapped bodies.`);
        }
    }
    // A ride kept from the player: the narration shows only the body. "His habits may show in what she does" asked for
    // the very tells the narration then had to explain away.
    for (const b of hidden) {
        const her = (b.pronouns.split('/')[0] || 'they').toLowerCase();
        const obj = { she: 'her', he: 'him' }[her] || 'them';
        rules.push(`${userName} doesn't know that ${b.body} is ${b.driver}. In narration ${her === 'they' ? 'they are' : `${her} is`} only ${b.body}, with ${b.body}'s own name and pronouns, and nothing mentions, hints at or explains that anyone else is inside: whatever ${b.driver} does through ${obj} is written as what ${b.body} does and says, the way anyone watching would see it.`);
    }
    const powers = l.powers.map(p => `${p.who}: ${p.power}`).join('; ');
    const aliases = l.aliases.map(a => `${a.name} = ${a.aka.join(' = ')}`).join('; ');
    const hasBodies = l.bodies.length > 0 || lines.length > 0;
    const anySheet = lines.some(x => x.startsWith('  Who ')) || back.length > 0;
    // The two names are for bodies someone else drives; the player is "you" in theirs (the rule above).
    const othersDrive = l.bodies.some(b => b.body && !same(b.body, 'none') && b.driver && !players(b.driver) && !same(b.body, b.driver) && !knownSwap(b));
    return [
        '<body_ledger>',
        ...(hasBodies ? [
            `Who is in which body right now.${othersDrive ? ` Where ${userName} knows who is inside a body someone else drives, everything the world sees of it (how it moves and sounds, how people address it) uses the body's own name and pronouns, and the mind inside keeps its own name and pronouns only for what it thinks, wants or decides. Narration never points out who is inside.` : ''}`,
            ...lines,
            `Everyone else, ${userName} included unless listed, is in their own body.`,
        ] : []),
        ...(anySheet ? [`A "Who … is in their own life" line says who that person is to the people around them: their world, work and habits stay true to it. While someone else drives their body it isn't how the body acts; once they're back in it, it is.`] : []),
        ...(back.length ? ['Back in their own bodies and still in the scene, so you play them again:', ...back.map(x => `- ${x.body}.\n${who(x.body, x.text)}`)] : []),
        ...(aliases ? [`Same person, different names: ${aliases}.`] : []),
        ...(powers ? [`Powers: ${powers}.`] : []),
        ...rules,
        'This is a record kept alongside the story. Where the chat itself says otherwise, the chat wins.',
        '</body_ledger>',
    ].join('\n');
}

// ------------------------------------------------------------------ possession lint (cut-only)

export const LINT_SYSTEM = `You cut specific lines out of body-swap roleplay prose. You may ONLY cut. Never add, reword, or move anything.
Cut exactly these, and nothing else:
{{rules}}
Copy each cut exactly, character for character, as it appears in the prose. Cut the smallest piece that removes the problem: a clause, a sentence, or one spoken line together with its speech tag. If nothing needs cutting, answer NONE.
Answer only in this form, one line per cut, or the single word NONE:
{{format}}`;

// Each cut names the rule it breaks, and a CONVERSING cut the body the line is spoken to, so the cutter can check the
// claim before it cuts (cutEvidence). Without the tags, a model cut two of one mind's bodies answering the player in
// turn as "conversing" (the Writer Gym, 2026-11-01: 4 of 5 cuts on real replies were fine lines).
export const CUT_FORMAT = 'CUT [RULE]: <exact text>\nwhere RULE is the rule\'s name: CONVERSING, SYNC, POINTER or SECRET. For CONVERSING, add the body the line is spoken to: CUT [CONVERSING → Donna]: <exact text>';

/**
 * The cut check's request. `lastUserText` is the player's message the prose answers: without it, two bodies of one
 * mind answering the player's question read as answering each other, and got cut as conversing (Writer Gym, 2026-11-01).
 */
export function buildLintMessages(text, ledger, userName = 'the player', { lastUserText = '' } = {}) {
    const l = normalizeLedger(ledger);
    const rules = [];
    const groups = multiBodyGroups(l);
    for (const g of groups) {
        const bodies = [...g.bodies, ...(g.ownToo ? [g.driver] : [])];
        if (!g.hidden) {   // when the player doesn't know, the bodies are right to talk like separate people
            rules.push(`- CONVERSING. ${list(bodies)} are all one person, ${g.driver}. Cut a spoken line, with its speech tag, only when one of them is speaking TO another of them as though it were a different person (addressing it, answering what it just said, joking or arguing with it), and narration that frames such an exchange ("a joke with herself", "answering himself"). A line spoken to anyone else is never this, not even when two of them speak one after the other or one finishes what another started: that is one person talking through two mouths. NEVER cut touching, kissing, sex, pleasuring, or looking at each other, and never cut one body talking ABOUT another, or about ${g.driver}'s own body, to someone else.`);
        }
        rules.push(`- SYNC. Narration in which two or more of ${list(bodies)} do the same thing at the same moment, move in unison, mirror each other, or speak the same words in chorus ("both glance over at the same instant", "all four speaking at once", "in perfect sync"). Cut the sentence or clause that describes it. Different bodies doing different things at once is correct and stays, and so do two of them speaking one after the other. Leave it only if the story shows ${g.driver} is new to the ability.`);
    }
    // Swapped bodies are named through the person inside on purpose, so the pointer cut leaves them alone.
    const swaps = [...new Set(l.bodies.filter(knownSwap).map(b => b.body))];
    if (swaps.length) rules.push(`- Never cut narration about ${list(swaps)}: they are in a body swap, where naming the person inside and whose body they're in is how the story stays clear ("Rika plants Rowan's big hand on the counter").`);
    // The player is "you" in every body they drive, and naming the body is how a sentence says which one.
    const canon = aliasResolver(l);
    const mine = [...new Set(l.bodies.filter(b => b.body && b.driver && canon(b.driver) === canon(userName) && !same(b.body, b.driver)).map(b => b.body))];
    if (mine.length) rules.push(`- Never cut narration that calls ${userName} "you" in ${list(mine)}, or that names the body to say which one "you" are moving ("as ${mine[0]}, you pour") or whose things they are ("${mine[0]}'s phone"): that is how the story talks about ${userName}'s own bodies. Words like "borrowed" or "isn't hers" still get cut.`);
    if (l.bodies.some(b => b.body && b.driver && !same(b.body, b.driver) && !knownSwap(b))) rules.push('- POINTER. Narration that points out someone else is inside a body: "Marcus\'s mannerism on her face", "his smile on her mouth", "her borrowed face", "someone else\'s mouth", "a smile that isn\'t hers", "something behind her eyes", "the amusement doesn\'t reach her eyes", "the same grin on three faces", "Victor\'s cadence makes it unsettling", bodies moving in eerie unison. Cut only the pointing words and keep the action: from "Dana rolls her eyes—Marcus\'s mannerism on her face." cut "—Marcus\'s mannerism on her face"; from "Cole\'s borrowed eyes go wide." cut just "borrowed " so it reads "Cole\'s eyes go wide."');
    for (const b of l.bodies.filter(b => b.user_knows === 'no' && b.body && b.driver)) {
        const aka = akaOf(l, b.driver);
        rules.push(`- SECRET. ${userName} does not know that ${b.body} is being driven by ${b.driver}${aka.length ? ` (also called ${aka.join(', ')})` : ''}. Cut narration that reveals or hints at it (naming ${b.driver} as the one inside ${b.body}, "possessed", "inside her", "wearing her", "piloting").`);
    }
    return [
        { role: 'system', content: LINT_SYSTEM.replace('{{rules}}', rules.join('\n')).replace('{{format}}', CUT_FORMAT) },
        { role: 'user', content: `${lastUserText ? `${userName}'s message, which the prose answers (for context only; a line that answers it is spoken to ${userName}):\n<<<\n${String(lastUserText).slice(0, 1500)}\n>>>\n\n` : ''}Prose:\n<<<\n${text}\n>>>` },
    ];
}

const SYNC_WORDS = /\b(both|all (?:two|three|four|five|of them)|together|in unison|at once|the same (?:time|instant|moment|second)|simultaneous\w*|in sync|perfect sync|mirror\w*|in chorus|lockstep|identical|the same (?:smile|grin|look|motion|movement|expression|words?))\b/i;
const POINTER_WORDS = /\b(borrowed|(?:is|was)n['’]t (?:hers|his|theirs)|not (?:hers|his|theirs|her own|his own|their own)|someone else|behind (?:her|his|their) eyes|mannerism|cadence|inside (?:her|him|them)|wearing (?:her|him|them)|piloting|puppet\w*|the same (?:grin|smile) on)\b/i;
const SECRET_WORDS = /\b(possess\w*|inside (?:her|him|them)|wearing (?:her|him|them)|piloting|behind (?:her|his|their) eyes|someone else|borrowed|(?:is|was)n['’]t (?:hers|his|theirs))\b/i;

/**
 * Whether a cut fits the rule it names, as far as the words can show: null when it does, else why not. `info` is
 * cutInfo()'s. CONVERSING needs the body it's spoken to, and that body must be another of one known mind's bodies;
 * SYNC needs two of one mind's bodies named, or words of unison; POINTER and SECRET need the rider named, or words that
 * say someone else is inside. A cut with no rule (an older "CUT: …" answer) passes if it fits any of them.
 */
export function cutEvidence(cut, rule, to, info) {
    const t = String(cut || '');
    const names = ns => ns.some(n => n && new RegExp(`(?<![\\p{L}])${n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(?![\\p{L}])`, 'iu').test(t));
    const conversing = () => {
        if (!to) return 'no body named that the line is spoken to';
        const g = info.groups.find(x => !x.hidden && x.names.some(n => same(n, to)));
        if (!g) return `${to} isn't another body of a mind with several`;
        if (same(to, info.user)) return 'spoken to the player';
        return /["“”]|\b(?:herself|himself|themself|themselves|each other|one another|the other (?:body|one))\b/i.test(t) ? null : 'not a spoken exchange';
    };
    const sync = () => (info.groups.some(g => g.names.filter(n => names([n])).length >= 2) || SYNC_WORDS.test(t) ? null : 'names no two bodies of one mind and nothing in unison');
    const pointer = () => (names(info.riders) || POINTER_WORDS.test(t) ? null : 'names no rider and says nothing of someone inside');
    const secret = () => (names(info.secrets) || SECRET_WORDS.test(t) ? null : 'names no hidden rider and says nothing of someone inside');
    switch (String(rule || '').toUpperCase()) {
        case 'CONVERSING': return conversing();
        case 'SYNC': return sync();
        case 'POINTER': return pointer();
        case 'SECRET': return secret();
        default: return [sync, pointer, secret].some(f => !f()) ? null : 'fits no rule';
    }
}

/** What cutEvidence needs from a ledger: each mind's bodies, every rider's names, and the hidden riders'. */
export function cutInfo(ledger, userName = '') {
    const l = normalizeLedger(ledger);
    const groups = multiBodyGroups(l).map(g => ({ hidden: g.hidden, names: [...g.bodies, ...(g.ownToo ? [g.driver] : []), ...g.bodies.flatMap(b => akaOf(l, b))] }));
    const rode = l.bodies.filter(b => b.body && b.driver && !same(b.body, b.driver) && !knownSwap(b));
    const withAka = bs => [...new Set(bs.flatMap(b => [b.driver, ...akaOf(l, b.driver)]))];
    return { groups, riders: withAka(rode), secrets: withAka(rode.filter(b => b.user_knows === 'no')), user: userName };
}

/** A regex that matches `s` while ignoring dash style/spacing, quote style, and runs of whitespace. */
function looseMatcher(s) {
    const esc = c => c.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    let src = '';
    for (const ch of s.trim()) {
        if (/[—–-]/.test(ch)) src += String.raw`\s*[—–-]\s*`;
        else if (/["“”]/.test(ch)) src += '["“”]';
        else if (/['‘’]/.test(ch)) src += "['‘’]";
        else if (/\s/.test(ch)) src += String.raw`\s+`;
        else src += esc(ch);
    }
    return new RegExp(src.replace(/(\\s\*|\\s\+)+/g, m => (m.includes('+') ? String.raw`\s+` : String.raw`\s*`)));
}

/**
 * Find `cut` in `text` ignoring asterisks (the model often drops italics markers) plus the looseMatcher slips.
 * Returns [start, end) in the original text, widened to take an italic marker that would otherwise dangle.
 */
function locateLoose(text, cut) {
    const map = [];
    let stripped = '';
    for (let i = 0; i < text.length; i++) if (text[i] !== '*') { map.push(i); stripped += text[i]; }
    const m = stripped.match(looseMatcher(cut.replace(/\*/g, '')));
    if (!m) return null;
    let s = map[m.index], e = map[m.index + m[0].length - 1] + 1;
    const inner = (text.slice(s, e).match(/\*/g) || []).length;
    if (inner % 2) {   // one marker of a pair is inside: take its partner if it sits right at an edge
        if (text[e] === '*') e++;
        else if (text[s - 1] === '*') s--;
    }
    return [s, e];
}

/** The cuts in an answer: { text, rule, to } each ("CUT [CONVERSING → Donna]: …"; an older "CUT: …" has no rule). */
export function parseLintResponse(text) {
    return String(text || '').split('\n').map(l => /^\s*CUT\s*(?:\[([^\]]*)\])?\s*:\s*(.+?)\s*$/i.exec(l)).filter(Boolean).map(m => {
        const [rule = '', to = ''] = String(m[1] || '').split(/\s*(?:→|->)\s*/);
        return { text: m[2], rule: rule.trim().toUpperCase(), to: to.trim() };
    });
}

/**
 * Apply cut-only fixes. Every cut must appear verbatim, stay under 400 characters, keep its quote marks
 * balanced, and all cuts together may remove at most 40% of the reply. Cuts are strings, or parseLintResponse's
 * { text, rule, to }; given `ledger` (and `userName`), a body-rule cut must also fit the rule it names (cutEvidence).
 */
export function applyCuts(text, cuts, { ledger = null, userName = '' } = {}) {
    let out = text;
    const applied = [], rejected = [];
    let removed = 0;
    const info = ledger ? cutInfo(ledger, userName) : null;
    for (const item of cuts) {
        let cut = String(typeof item === 'string' ? item : item?.text || '').replace(/^<<<|>>>$/g, '').trim();
        if (!cut) continue;
        const why = info ? cutEvidence(cut, item?.rule, item?.to, info) : null;
        if (why) { rejected.push({ cut, why }); continue; }
        let at = out.indexOf(cut);
        // allow the model to drop the outer asterisks of an italic span
        if (at < 0 && out.indexOf(`*${cut}*`) >= 0) { cut = `*${cut}*`; at = out.indexOf(cut); }
        // tolerate copying slips that don't change the words: dash style and spacing, curly quotes, whitespace,
        // and dropped italics asterisks
        if (at < 0) {
            const span = locateLoose(out, cut);
            if (span) { at = span[0]; cut = out.slice(span[0], span[1]); }
        }
        if (at < 0) { rejected.push({ cut, why: 'not found verbatim' }); continue; }
        if (cut.length > 400) { rejected.push({ cut, why: 'too long' }); continue; }
        const quotes = (cut.match(/["“”]/g) || []).length;
        if (quotes % 2) { rejected.push({ cut, why: 'would break a quote' }); continue; }
        if (removed + cut.length > Math.max(0.4 * text.length, 220)) { rejected.push({ cut, why: 'too much of the reply' }); continue; }
        // A cut from the middle of a sentence ("the store" out of "he went to the store.") leaves it broken.
        const next = deleteSpan(out, at, at + cut.length);
        if (leavesBroken(out, next)) { rejected.push({ cut, why: 'leaves a broken sentence' }); continue; }
        out = next;
        removed += cut.length;
        applied.push({ action: 'CUT', from: cut, ...(item?.rule ? { rule: item.rule } : {}) });
    }
    out = out
        .replace(/[ \t]*[—–][ \t]*([.!?,;])/g, '$1')            // "tilts her head —." → "tilts her head."
        .replace(/([.!?])[ \t]*[—–][ \t]*(?=\*|"|”|$)/gm, '$1')  // a dash left dangling before a closing mark
        .replace(/,[ \t]*([.!?])/g, '$1')
        .replace(/[ \t]{2,}/g, ' ')
        .replace(/ +([,.!?;:])/g, '$1')
        .replace(/\n{3,}/g, '\n\n')
        .replace(/^[ \t]+|[ \t]+$/gm, '');
    return { text: out, applied, rejected };
}

// ------------------------------------------------------------------ pronoun / name check

export const PRONOUNS = new Set('he him his himself she her hers herself they them their theirs themself themselves'.split(' '));

/** True when at least one body is driven by a mind with a different name or different pronouns. */
/** Whether the pronoun check has anything to look at: a body driven by someone else, other than in a known swap. */
export const needsPronounCheck = ledger => normalizeLedger(ledger).bodies.some(b => b.body && b.driver && !same(b.body, b.driver) && !knownSwap(b));

export function hasCrossedBodies(ledger) {
    return normalizeLedger(ledger).bodies.some(b => b.body && b.driver && !same(b.body, b.driver));
}

// A general "bodies get body pronouns, minds get mind pronouns" prompt makes a small model flip correct speech tags
// and movements ("she says" → "he says") and even swap who acted. This version says the default is correct and
// names the one thing to look for, which avoids false fixes and still catches the real errors.
export const PRONOUN_SYSTEM = `You check one specific mistake in body-swap roleplay prose. Given who is driving which body, find pronouns that refer to the DRIVING MIND itself but use the BODY's gender.
By default, pronouns follow the body, and that is correct: speech tags ("she says"), movements, gestures, looks, clothes, and body parts of a possessed body use the BODY's pronouns. Never touch those.
Only a pronoun whose referent is plainly the driving mind as a person gets the mind's pronouns: its identity and history, its own plans and wants stated as the mind's ("he's wanted this for years"), its attention split across bodies, or its own separate body.
Never change who performs an action, and never replace one character's name with another's.
Example, with Alice's body (she/her) driven by Marcus (he/him):
- "Not long," she says. She sets the eggs down. → correct, leave it.
- She has been planning this since he first saw her at the gym. → BAD: the planner is Marcus's mind. FIX: He has been planning this since he first saw her at the gym.
When in doubt, leave it. Report at most three.
Answer only in this form, one pair per mistake, or the single word NONE:
BAD: <the exact sentence, copied character for character>
FIX: <the sentence with only the pronouns or names changed>`;

export function buildPronounMessages(text, ledger) {
    const l = normalizeLedger(ledger);
    const map = l.bodies.filter(b => b.body && b.driver && !same(b.body, b.driver) && !knownSwap(b))
        .map(b => `- The body of ${b.body} (${b.pronouns || '?'}) is driven by ${b.driver} (${b.driver_pronouns || '?'}).`).join('\n');
    return [
        { role: 'system', content: PRONOUN_SYSTEM },
        { role: 'user', content: `Who is in which body:\n${map}${l.aliases.length ? `\nSame person, different names: ${l.aliases.map(a => [a.name, ...a.aka].join(' = ')).join('; ')}` : ''}\n\nProse:\n<<<\n${text}\n>>>` },
    ];
}

export function parsePronounResponse(text) {
    const out = [];
    const lines = String(text || '').split('\n');
    for (let i = 0; i < lines.length; i++) {
        const bad = lines[i].match(/^\s*BAD:\s*(.+)$/i);
        if (!bad) continue;
        const fix = (lines[i + 1] || '').match(/^\s*FIX:\s*(.+)$/i);
        if (fix) { out.push({ bad: bad[1].trim(), fix: fix[1].trim() }); i++; }
    }
    return out;
}

const tokens = s => String(s).match(/[A-Za-z']+|[^\sA-Za-z']/g) || [];

/**
 * Accept a fix only if it is the same sentence with nothing but pronouns and ledger names swapped, and the
 * original sentence appears verbatim in the text. Returns the applied text and a log.
 */
export function applyPronounFixes(text, pairs, ledger) {
    const l = normalizeLedger(ledger);
    const names = new Set([...l.bodies.flatMap(b => [b.body, b.driver]), ...l.aliases.flatMap(a => [a.name, ...a.aka])]
        .filter(Boolean).flatMap(n => n.toLowerCase().split(/\s+/)));
    const swappable = w => {
        const x = w.toLowerCase().replace(/'s$/, '');
        return PRONOUNS.has(x) || names.has(x);
    };
    let out = text;
    const applied = [], rejected = [];
    for (const { bad, fix } of pairs) {
        const b = bad.replace(/^[*"“]+|[*"”]+$/g, '').trim(), f = fix.replace(/^[*"“]+|[*"”]+$/g, '').trim();
        if (!b || b === f) continue;
        const at = out.indexOf(b);
        if (at < 0) { rejected.push({ bad: b, fix: f, why: 'sentence not found verbatim' }); continue; }
        const tb = tokens(b), tf = tokens(f);
        if (tb.length !== tf.length) { rejected.push({ bad: b, fix: f, why: 'changed more than pronouns/names' }); continue; }
        let changed = 0, ok = true;
        for (let i = 0; i < tb.length; i++) {
            if (tb[i] === tf[i]) continue;
            if (swappable(tb[i]) && swappable(tf[i])) { changed++; continue; }
            if (tb[i].toLowerCase() === tf[i].toLowerCase()) continue; // capitalization only
            ok = false; break;
        }
        if (!ok || !changed) { rejected.push({ bad: b, fix: f, why: ok ? 'no pronoun or name changed' : 'changed more than pronouns/names' }); continue; }
        out = out.slice(0, at) + f + out.slice(at + b.length);
        applied.push({ from: b, to: f });
    }
    return { text: out, applied, rejected };
}

// ------------------------------------------------------------------ body history
// Past possessions, worked out from the per-message ledger snapshots, so the history follows swipes, edits and
// deleted messages with nothing extra to keep in sync. The only thing stored besides the snapshots is a short
// note per ended possession (what the host remembers, what the driver kept, what the ride left behind), written
// by the local model on the message where the Ledger shows the possession ending.

// A ride is keyed by who is driving whom, through aliases, so "Sasha" and "Unit 114" are one body.
const pairKeyWith = canon => (driver, body) => `${canon(driver)}\u0000${canon(body)}`;
const pairKey = pairKeyWith(lc);
const rides = l => normalizeLedger(l).bodies.filter(b => b.driver && b.body && !same(b.body, 'none') && !same(b.body, b.driver));

/** Possessions in `before` that are gone from `after`: the row was removed or someone else drives the body now. */
export function endedRides(before, after) {
    const key = pairKeyWith(aliasResolver(before, after));
    const now = new Set(rides(after).map(b => key(b.driver, b.body)));
    return rides(before).filter(b => !now.has(key(b.driver, b.body)));
}

/**
 * Every possession episode in the chat, oldest first.
 * @param {{index:number, ledger:object, notes?:object[]}[]} snaps  ledger snapshots in chat order
 * @param {number} [gap]  a pair missing from this many snapshots in a row still counts as one ride, since the
 *                        ledger model occasionally drops a row for a turn and puts it back
 * @returns {{driver, body, how, host, start, end, user_knows, notes}[]}  end is null while the ride goes on
 */
export function bodyHistory(snaps, gap = 1) {
    // Aliases learned anywhere in the chat apply to all of it: a body renamed later is still the same body.
    const pairKey = pairKeyWith(aliasResolver(...snaps.map(s => s.ledger)));
    const open = new Map();
    const closed = [];
    snaps.forEach((snap, si) => {
        const cur = new Map(rides(snap.ledger).map(b => [pairKey(b.driver, b.body), b]));
        for (const [key, b] of cur) {
            let ep = open.get(key);
            if (!ep) {
                const last = closed.findLast(e => e.key === key);
                if (last && si - last.lastSeen - 1 <= gap) {
                    closed.splice(closed.indexOf(last), 1);
                    Object.assign(last, { end: null, notes: null });
                    ep = last;
                } else {
                    ep = { key, driver: b.driver, body: b.body, start: snap.index, end: null, notes: null };
                }
                open.set(key, ep);
            }
            // Latest names win, so the history uses what the story calls them now.
            Object.assign(ep, { driver: b.driver, body: b.body, how: b.how || ep.how || '', host: b.host || ep.host || '', user_knows: b.user_knows, lastSeen: si });
        }
        for (const [key, ep] of open) {
            if (cur.has(key)) continue;
            ep.end = snap.index;
            open.delete(key);
            closed.push(ep);
        }
        for (const n of normalizeNotes(snap.notes)) {
            const ep = closed.findLast(e => e.key === pairKey(n.driver, n.body) && e.end === snap.index);
            if (ep) ep.notes = n;
        }
    });
    return [...closed, ...open.values()].sort((a, b) => a.start - b.start)
        .map(({ lastSeen, ...ep }) => ep);
}

/** Like str(), but a long note ends at a word boundary instead of mid-word. */
const phrase = (v, max = 160) => {
    const s = str(v, 400).replace(/[.;,\s]+$/, '');
    if (s.length <= max) return s;
    return s.slice(0, max).replace(/[\s,;]+\S*$/, '');
};

// The aftermath of a ride, noted when it ends: what the host remembers and how they explain it to themselves, what
// they're now held to (said, sent or promised in their name), who saw what, what the driver took, and what changed.
export const NOTE_FIELDS = ['remembers', 'believes', 'owns', 'seen', 'kept', 'left'];

export function normalizeNotes(raw) {
    return (Array.isArray(raw) ? raw : []).map(n => ({
        driver: str(n?.driver, 60), body: str(n?.body, 60),
        ...Object.fromEntries(NOTE_FIELDS.map(k => [k, phrase(n?.[k])])),
    })).filter(n => n.driver && n.body && NOTE_FIELDS.some(k => n[k]));
}

/**
 * Ended rides grouped for display, most recent first: one entry per driver→body pair, and bodies that share
 * everything but their name (a rig of unnamed hosts released together) folded into one. Used by the prompt text
 * and the settings panel.
 */
// `edits` are your corrections, by pair key: { removed } hides the rides that had ended by then (a ride after it shows
// again), and { at, notes, how, host, user_knows } stands in for what the notes model and the Ledger said up to then.
// A ride that ends after the edit adds its own notes on top.
export function historyGroups(episodes, { max = 10, edits = {} } = {}) {
    const pairs = new Map();
    for (const ep of episodes) {
        const key = ep.key ?? pairKey(ep.driver, ep.body);
        const e = edits[key];
        const before = at => ep.end != null && at != null && ep.end <= at;
        if (before(e?.removed)) continue;
        const p = pairs.get(key) || { key, driver: ep.driver, body: ep.body, ended: 0, ongoing: false, lastEnd: -1, how: '', host: '', user_knows: 'yes',
            notes: Object.fromEntries(NOTE_FIELDS.filter(k => e?.notes?.[k]).map(k => [k, e.notes[k]])) };
        if (ep.end == null) p.ongoing = true;
        else { p.ended++; p.lastEnd = Math.max(p.lastEnd, ep.end); }
        p.how = ep.how || p.how;
        p.host = ep.host || p.host;
        p.user_knows = ep.user_knows || p.user_knows;
        if (!(e?.notes && before(e.at))) for (const k of NOTE_FIELDS) if (ep.notes?.[k]) p.notes[k] = ep.notes[k];
        pairs.set(key, p);
    }
    for (const [key, p] of pairs) for (const f of ['how', 'host', 'user_knows']) if (edits[key] && f in edits[key]) p[f] = edits[key][f];
    // Bodies that share everything but their name (a rig of unnamed hosts released together) get one line.
    const groups = new Map();
    for (const p of [...pairs.values()].filter(p => p.ended)) {
        const sig = JSON.stringify([p.driver.toLowerCase(), p.ended, p.ongoing, p.how, p.notes.remembers ? '' : p.host, p.notes, p.user_knows]);
        const g = groups.get(sig) || { ...p, bodies: [], keys: [] };
        g.bodies.push(p.body);
        g.keys.push(p.key);
        g.lastEnd = Math.max(g.lastEnd, p.lastEnd);
        groups.set(sig, g);
    }
    return [...groups.values()].sort((a, b) => b.lastEnd - a.lastEnd).slice(0, max);
}

/**
 * The text injected into the prompt. Only ended rides: the Ledger already covers what is happening now. With `scene`
 * (the latest messages), the full aftermath goes to people named in it, the ones a reply can actually meet; everyone
 * else gets one line.
 */
export function renderHistory(episodes, userName = '{{user}}', { max = 10, scene = null, edits = {} } = {}) {
    const lines = historyGroups(episodes, { max, edits }).map(g => {
        const many = g.bodies.length > 1;
        const who = list(g.bodies);
        const times = (g.ended === 1 ? 'once' : g.ended === 2 ? 'twice' : `${g.ended} times`) + (many ? ' each' : '');
        let line = `- ${g.driver} has been in ${who} ${times}${g.how ? ` (${g.how})` : ''}${g.ongoing ? ', and is again now' : ''}.`;
        const here = scene == null || g.bodies.some(b => personNamedIn(scene, [b]));
        if (here) {
            if (g.notes.remembers) line += ` ${who} ${many ? 'remember' : 'remembers'}: ${g.notes.remembers}.`;
            else if (g.host) line += ` ${many ? 'Their own minds' : `${who}'s own mind`} while ridden: ${g.host}.`;
            if (g.notes.believes) line += ` As ${many ? 'they see' : `${who} sees`} it: ${g.notes.believes}.`;
            if (g.notes.owns) line += ` Held to: ${g.notes.owns}.`;
            if (g.notes.seen) line += ` Seen: ${g.notes.seen}.`;
            if (g.notes.kept) line += ` ${g.driver} kept: ${g.notes.kept}.`;
            if (g.notes.left) line += ` It left ${many ? 'them' : who} with: ${g.notes.left}.`;
        }
        if (g.user_knows === 'no') line += ` HIDDEN from ${userName}.`;
        return line.replace(/\.\./g, '.');
    });
    if (!lines.length) return '';
    return [
        '<body_history>',
        `Possessions in this story that have ended (who is in which body right now is in the Body Ledger). This is continuity: people live with the consequences the way they naturally would. Someone who was ridden acts on what they believe happened and on what they're held to, never on the truth they don't know, and people who saw something remember it. Narration doesn't recap these rides or point back at them, and whatever is hidden from ${userName} stays hidden.`,
        ...lines,
        '</body_history>',
    ].join('\n');
}

export const HISTORY_SYSTEM = `You keep the aftermath of possessions in an adult roleplay: what a ride leaves behind once the driving mind has left a body, so later scenes stay true to it. One or more possessions have just ended. From the messages, note for each one:
- remembers: what the body's own person remembers of the ridden time, judged by what they say or do once they're themselves again, or by the card's rule when one is given. "" if neither shows it.
- believes: how they explain the ridden time to themselves, in their own terms ("a night she drank too much", "zoned out at her desk"), when the messages or the card's rule make it plain. "" otherwise.
- owns: what was said, sent, promised or done in their name while ridden that the people around them will now hold them to, and who it was said or sent to, in under 25 words. "" if nothing.
- seen: who saw the host do or say something during the ride that they'll bring up with the host later, and what, in under 20 words. What anyone worked out about the powers isn't noted here. "" if nobody did.
- kept: only something the driver took away on leaving: memories or skills copied out, or an object carried off in another body. Things that stay with the host are not "kept".
- left: lasting changes to the body itself, in under 15 words: marks, changes to how it looks or feels. No tastes, aches or moods.
Give each body only what the messages show for that body (and the card's rule, for remembers and believes). An empty field is better than a wrong one: write "" for anything not clearly shown.
Answer with JSON only, in exactly this shape:
[{"driver":"","body":"","remembers":"","believes":"","owns":"","seen":"","kept":"","left":""}]`;

/**
 * @param {{driver, body, host}[]} ended  @param {{name:string, text:string}[]} messages  newest messages, oldest first
 * @param {{aftermath?: string}} [o]  what the card's rules say a host remembers (rules-core), when they say
 */
export function buildHistoryMessages(ended, messages, { aftermath = '' } = {}) {
    const list = ended.map(b => `- ${b.driver} has left ${b.body}${b.host ? ` (while ridden, ${b.body}'s own mind was ${b.host})` : ''}`).join('\n');
    const rule = aftermath ? `\n\nThe card's rule for every host: when the rider leaves, the host remembers ${aftermath.charAt(0).toLowerCase() + aftermath.slice(1)}. Unless the messages show otherwise, that is what "remembers" says.` : '';
    return [
        { role: 'system', content: HISTORY_SYSTEM },
        { role: 'user', content: `Possessions that just ended:\n${list}${rule}\n\nNewest messages, oldest first:\n${messages.map(m => `### ${m.name}\n${clip(m.text, 2500)}`).join('\n\n')}\n\nNow output the JSON.` },
    ];
}

/** Notes for the ended rides only (matched by name), or [] if the answer can't be read. */
export function parseHistoryResponse(text, ended) {
    // First complete array (a model may keep talking after it); a lone object is taken as a one-item list.
    let raw = firstJson(text, '[');
    if (!Array.isArray(raw)) { const one = firstJson(text); raw = one && typeof one === 'object' ? [one] : null; }
    if (!Array.isArray(raw)) return [];
    const wanted = new Set(ended.map(e => pairKey(e.driver, e.body)));
    const empty = /^(none|none shown|not shown|n\/a|unknown|nothing stated|not stated|-)$/i;
    return normalizeNotes(raw.map(n => ({ ...n, ...Object.fromEntries(NOTE_FIELDS.map(k => [k, empty.test(String(n?.[k] ?? '').trim()) ? '' : n?.[k]])) })))
        .filter(n => wanted.has(pairKey(n.driver, n.body)));
}
