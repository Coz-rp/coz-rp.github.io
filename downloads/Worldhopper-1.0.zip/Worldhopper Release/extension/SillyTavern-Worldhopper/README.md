# Worldhopper Engine

A SillyTavern extension for metaphysics roleplay: possession, body swaps, mind control, hive minds, dolls and more. It pairs with the Worldhopper and WH Planeswalker presets, and works with any Chat Completion or Text Completion setup.

## What it does

- **Codex modes.** Pick the kinds of metaphysics a character uses, from 20 modes (possession, multipossession, skinsuits, hive minds, hypnosis, mind control, dolls, time stop and more). The extension switches on the matching rules from its Codex lorebook in that character's chats only. The lorebook comes with the extension and installs and updates itself; if you edit your copy, updates wait for your OK.
- **Body Ledger.** After each reply, a model you choose records who is in which body, who has which power, and whether you know. It goes into the prompt so names and pronouns stay straight, and it shows as a strip above the chat: teal when you're the one inside someone, violet when someone else is. While you're in someone else's body, your messages carry an "as (name)" badge. Body History remembers past body changes and what they left behind.
- **Body roster.** While you run more than one body (Multipossession, or you as a hive), a card per body sits over the message box in that body's colour, saying what it's doing. Tap one to start a line for that body, like `[Kayla] takes the keys`; those lines show in the chat as rows in the same colours. A line with no name is you as a whole. The writer only ever does what you wrote with your bodies: one you gave nothing stays as you left it.
- **Possession moments.** When the writer marks a takeover or an exit, it appears as a styled box in the chat.
- **Editor.** After each reply, a rule pass flags stock phrases, "not X, but Y" framing, chopped dialogue and the like, and a model rewrites only those lines. The ⟲ button in a message's menu switches between the original and the fixed version.
- **Card tools** (wand menu). **Make card** turns a Metaphysics Card Builder chat into a character with its modes already set. **Check card** reviews the open character's card for problems, with an optional deeper review by a model.

## Requirements

- SillyTavern with the built-in Connection Manager. Tested on SillyTavern 1.18.
- At least one connection profile (plug menu → Connection Profile). The Ledger runs after every reply, so a fast model suits it; a local model through KoboldCpp works well. History notes and card reviews benefit from a stronger model.

## Install

1. In SillyTavern, open Extensions, choose **Install extension**, and paste this repository's address: `https://github.com/Coz-rp/SillyTavern-Worldhopper`
2. Open Extensions → Worldhopper Engine → Settings → Models, and pick a profile for **Ledger & suggestions**, **Editor**, and **Notes & reviews**.

To install by hand instead, copy this folder into `SillyTavern/public/scripts/extensions/third-party/` and restart SillyTavern.

On first start the extension installs the WH Metaphysics lorebook and four display-only regex scripts (WH - Possession, WH - Release, WH - Stray possession markers, WH - Body lines). You can edit or delete the scripts; the extension leaves your changes alone. The same scripts are available as files on https://coz-rp.github.io/ in case you need to import them yourself.

The Worldhopper 1.0 presets for Claude and Gemini, and the Metaphysics Card Builder with its WH Cardmaker preset, are on https://coz-rp.github.io/

## Using it

Open a character and pick its modes under **Modes** (the pen button), or let the wand suggest some. From then on the Codex and the Body Ledger run in that character's chats. Every section of the panel has a (?) button that explains it in a few lines.

Slash commands:
- `/wh-modes` shows or sets the current character's modes, e.g. `/wh-modes Possession, Skinsuit`.
- `/wh-ledger` shows the Ledger; `/wh-ledger rebuild`, `edit`, `history` and `backfill` do what they say.
- `/wh-edit` runs the Editor on the last reply (or a message id).

## Privacy

The extension sends chat text only to the connection profiles you pick under Models: the Ledger model reads the last few messages after each reply, the Editor model reads the lines it fixes, the notes model reads the messages around an ended body change, and a deeper card review sends that card. Nothing else leaves your SillyTavern, and there's no telemetry.

## Optional: phone off-switch

`extras/wh-power` is a small server plugin for Windows that adds **Shut down SillyTavern** to the wand menu, for switching SillyTavern off from your phone. It isn't installed with the extension; see its README.

## Credits

Worldhopper Engine by Coz, built with Claude.
