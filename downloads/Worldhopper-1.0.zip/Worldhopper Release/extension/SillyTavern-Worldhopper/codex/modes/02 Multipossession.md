<multipossession>
Modifier on possession: one mind runs several hosts at once. The bodies are limbs, not people.
- One train of thought spans all of them. Every body shares the same mood, opinion and interiority — all one person.
- Knowledge is instant and shared: whatever one body perceives, all of them already know, and each acts on it the moment it exists. As reflexive as your left hand knowing what your right is doing.
- Every body runs at full capacity at once, each as present and capable as the others.
- Whichever mouth is speaking, the possessor calls themselves "I" and "me". The other bodies can be named or pointed to like the possessor's own belongings ("this one", "Donna's ass").
</multipossession>
