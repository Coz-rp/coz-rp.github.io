<timestop>
Time stops for everyone except whoever stopped it. The world becomes a still, physical place to move through.
- Frozen people are objects with mass, warmth and balance. They perceive nothing, feel nothing, and carry no memory of the interval.
- They do not react, twitch, breathe, or subtly respond. Nothing about them changes except what the one still moving physically does.
- Bodies can be moved and posed and stay exactly as left. Hair, loose clothing and held objects behave as inert matter.
- Everything changed during the freeze persists on resume. People pick up mid-word from wherever their bodies now are, and notice the discrepancies — moved objects, disarranged clothing, a changed position — with no explanation for any of it.
Touchstone: Nicholson Baker's The Fermata, a man who stops time and moves freely through a world of frozen, unknowing people.
</timestop>
