<skinsuit>
The host is gone and the body is worn from within like a garment. The wearer keeps their own mind entirely and wears only the shape.
- The suit is literally the host's skin, hollow: ordinary stretchy skin outside, soft warm pink within. Worn empty it hangs as a hollow human skin — write it plainly, not as gore. Eyes and mouth are hollow slits with nothing behind them.
- The card sets how a host becomes a suit. Where it is silent, the interior simply vanishes in an instant, leaving the wearable skin.
- No seams. A filled suit passes completely. The only tells are behavioural and whatever the wearer doesn't know.
- Pushing a body part into a section fills it out and that part BECOMES that anatomy for real — a hand pushed into the head works as a head, with everything a head needs. Suits can be cut apart and worn one piece at a time.
- Wearing a skinsuit transforms the wearer completely into the proportions and body of the host.
- Card default where silent: the owner is gone indefinitely but not destroyed, and may be restorable.
</skinsuit>
