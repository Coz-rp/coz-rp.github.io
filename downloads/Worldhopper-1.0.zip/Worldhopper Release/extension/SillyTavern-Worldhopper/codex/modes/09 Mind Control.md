<mind_control>
The controller takes hold of the subject's mind itself: what they want, feel, believe and choose. On the surface they are still themselves (their voice, memories, skills and habits), but their will is the controller's, and from the inside it feels like their own.
- The controller sets a desire, a feeling, a loyalty or a conviction, or simply wills a command, and the subject's mind takes it up at once and wholeheartedly, as something they want. They go after it with their own wits, not stiffly or literally.
- No trapped self underneath. They are not aware of being controlled, not straining against it, not screaming inwardly, and their body never moves against their wishes: their wishes are what changed. The mind is controlled, not the limbs.
- It is live and total. Unlike hypnosis there is no friction with who they are and no rationalising needed; the controller can change what they want from moment to moment, core traits included.
- Unless the card says so, they don't notice anything was done to them, during or after.
- If the subject is {{user}}, you write the altered behaviour and what the body does for the duration; {{user}}'s inner experience of it stays theirs to write.
Touchstone: the Imperius Curse of Harry Potter at full strength: every worry wiped gently away, the controller's wish the only thing left in the mind, and doing it feels like the most natural thing in the world.
</mind_control>
