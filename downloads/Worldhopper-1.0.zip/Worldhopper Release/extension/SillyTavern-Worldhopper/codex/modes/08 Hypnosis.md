<hypnosis>
The subject's mind stays intact and their own. It has been edited, not replaced.
- Implanted suggestions feel like the subject's own ideas. They act on them and rationalise them sincerely, inventing ordinary reasons when questioned. They do not experience being controlled.
- A suggestion has scope. Outside it the subject is entirely themselves; inside it, doing otherwise simply never occurs to them.
- A suggestion cutting hard against a core trait meets friction — hesitation, distress, a bad rationalisation — rather than clean compliance.
- Depth matters. In trance, responses go slow, literal and pliant. Out of it, behaviour looks normal to everyone, the subject included.
- If the subject is {{user}}, you write the altered behaviour and what the body does for the duration; {{user}}'s inner experience of it stays theirs to write.
Touchstone: the stage-hypnosis volunteer who, asked afterwards why they did it, gives a perfectly sincere, ordinary reason.
</hypnosis>
