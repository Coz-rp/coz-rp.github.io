# Worldhopper 1.0

Metaphysics roleplay for SillyTavern: possession, body swaps, mind control, hive minds, dolls, time stops and more, written well. By Coz. Home page: https://coz-rp.github.io/

| Folder | What it is |
| --- | --- |
| `presets/` | **Worldhopper 1.0** (tuned for Claude), **WH Planeswalker 1.0** (tuned for Gemini) and **WH Delver 1.0** (tuned for DeepSeek): modular Chat Completion roleplay presets. **WH Cardmaker 1.0**: a preset for building cards with the Card Builder. |
| `extension/SillyTavern-Worldhopper/` | **Worldhopper Engine**: per-character metaphysics modes, a Body Ledger of who is in which body and whose mind was changed, a prose Editor, and card tools. Also on GitHub: https://github.com/Coz-rp/SillyTavern-Worldhopper |
| `cards/` | **Metaphysics Card Builder**: a character that helps you write metaphysics cards, one piece at a time. |
| `regex/` | The regex scripts on their own, in case your SillyTavern doesn't pick them up from the presets or the extension. |

The presets work without the extension (just without metaphysics rules), and the extension works with other presets.

## Install

1. **Presets.** In SillyTavern, open AI Response Configuration (the sliders icon), choose Import preset, and pick a file from `presets/`. When SillyTavern asks whether to allow the preset's regex scripts, allow them. Each preset's first block (✦ README, keep it off) explains every toggle.
2. **Extension.** In SillyTavern, open Extensions, choose Install extension, and paste `https://github.com/Coz-rp/SillyTavern-Worldhopper`. (Or copy `extension/SillyTavern-Worldhopper` into `SillyTavern/public/scripts/extensions/third-party/` and restart.) Then open Extensions → Worldhopper Engine → Settings → Models and pick a connection profile for each job. Use a local model or a cheap, fast API model there, not your roleplay model: the Ledger runs after every reply, so that keeps everything quick and nearly free.
3. **Card builder.** Open Characters, choose Import, and pick `cards/Metaphysics Card Builder.json`. Chat with it with the WH Cardmaker preset selected to build a card; when it's done, choose Make card in the wand menu.
4. **Regex, only if needed.** The presets carry their regex and the extension installs its own, so you normally need nothing from `regex/`. If styled texts or moment boxes don't show, open Extensions → Regex, choose Import, and pick `WH regex pack (presets).json` or `WH regex pack (engine).json`. Importing a script you already have does no harm.

Optional: the extension includes `extras/wh-power`, a Windows server plugin that shuts SillyTavern down from another device, such as your phone. See its README.
