# Worldhopper 1.1

Metaphysics roleplay for SillyTavern: possession, body swaps, mind control, hive minds, dolls, time stops and more, written well. By Coz. Home page: https://coz-rp.github.io/

| Folder | What it is |
| --- | --- |
| `presets/` | **Worldhopper 1.1**: the flagship modular Chat Completion roleplay preset, with every model's setup in one: a block meant for some models starts with a coloured dot for each (🟠 Claude, 🔵 Gemini, 🟢 DeepSeek, 🟣 GLM), and the README inside says what to switch for yours. **WH Shifter 1.1** (Claude), **WH Planeswalker 1.1** (Gemini), **WH Delver 1.1** (DeepSeek) and **WH Nomad 1.1** (GLM): one per model family, holding only that family's blocks, with its samplers set. **WH Cardmaker 1.1**: a preset for building cards with the Card Builder. |
| `extension/SillyTavern-Worldhopper/` | **Worldhopper Engine**: per-character metaphysics modes, a Body Ledger of who is in which body, and card tools. Also on GitHub: https://github.com/Coz-rp/SillyTavern-Worldhopper |
| `extension/SillyTavern-WH-Editor/` | **WH Editor**: fixes stock phrases, "not X, but Y" framing, chopped dialogue and other model tells, rewriting only the lines it flags. Works with or without the Engine. Also on GitHub: https://github.com/Coz-rp/SillyTavern-WH-Editor |
| `cards/` | **Metaphysics Card Builder**: a character that helps you write metaphysics cards, one piece at a time. |
| `regex/` | The regex scripts on their own, in case your SillyTavern doesn't pick them up from the presets or the extension. |

The presets work without the extension (just without metaphysics rules), and the extension works with other presets.

## Install

1. **Preset.** In SillyTavern, open AI Response Configuration (the sliders icon), choose Import preset, and pick the preset for your model from `presets/`, such as `WH Shifter 1.1.json` for Claude, or the flagship `Worldhopper 1.1.json` if you switch between models. When SillyTavern asks whether to allow the preset's regex scripts, allow them. Its first block (✦ README, keep it off) explains every toggle. In the connection settings, set Prompt Post-Processing to Semi-strict (no tools).
2. **Extension.** In SillyTavern, open Extensions, choose Install extension, and paste `https://github.com/Coz-rp/SillyTavern-Worldhopper`. (Or copy `extension/SillyTavern-Worldhopper` into `SillyTavern/public/scripts/extensions/third-party/` and restart.) Then open Extensions → Worldhopper Engine → Settings → Models and pick a connection profile for each job. For the **WH Editor**, install `https://github.com/Coz-rp/SillyTavern-WH-Editor` the same way and pick its model under Extensions → WH Editor. Use a local model or a cheap, fast API model there, not your roleplay model: the Ledger runs after every reply, so that keeps everything quick and nearly free.
3. **Card builder.** Open Characters, choose Import, and pick `cards/Metaphysics Card Builder.json`. Chat with it with the WH Cardmaker preset selected to build a card; when it's done, choose Make card in the wand menu.
4. **Regex, only if needed.** The presets carry their regex and the extension installs its own, so you normally need nothing from `regex/`. If styled texts or moment boxes don't show, open Extensions → Regex, choose Import, and pick `WH regex pack (presets).json` or `WH regex pack (engine).json`. Importing a script you already have does no harm.

Optional: the extension includes `extras/wh-power`, a Windows server plugin that shuts SillyTavern down from another device, such as your phone. See its README.
